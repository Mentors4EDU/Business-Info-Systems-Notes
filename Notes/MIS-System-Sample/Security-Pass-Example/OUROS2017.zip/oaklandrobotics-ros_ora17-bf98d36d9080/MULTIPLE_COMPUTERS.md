Mutiple Computers
-----------------

# Static IP Addresses
Configure both computers for static IP addresses. Currently the stereo vision computer, the top laptop, is set to 192.168.0.100 and the mapping computer, the bottom laptop, is set to 192.168.0.101.

# Time Synchronization
Chrony is used to synchronize small changes in time between the two computers. If there is a significant difference in time, chrony will take a long time to synchronize completely. To expedite this process a bash script has been created to immediately synchronize the two computers' times: ora_launch/scripts/time_sync.bash. To just check how far the times are off run ora_launch/scripts/time_check.bash.  More info on the subject is here:
http://wiki.ros.org/ROS/NetworkSetup#Timing_issues.2C_TF_complaining_about_extrapolation_into_the_future.3F

# ROS Core Across Multiple Machines
http://wiki.ros.org/ROS/Tutorials/MultipleMachines