Setup
------------------------------------------

This codebase is developed in the following environment:
**OS:** Ubuntu 16.04 LTS desktop amd64
**ROS:** Kinetic
**Hg:** TortoiseHg
**IDE:** Eclipse Neon

# Ubuntu
This code base is developed in Ubuntu 16.04 LTS amd64. Ubuntu 16.04 LTS can be downloaded here: http://releases.ubuntu.com/16.04/  

# ROS Kinetic
The instructions for installing ROS Kinetic Desktop-Full can be found here: http://wiki.ros.org/kinetic/Installation/Ubuntu.  
If the installation was successful, you should be able to run roscore from the terminal.
```
roscore
```

Create a ROS workspace
```
cd
mkdir -p ros/src
cd ros
catkin_make
echo "source ~/ros/devel/setup.bash" >> ~/.bashrc
source ~/.bashrc
```


# TortoiseHg
Install the version control software. Mercurial (hg) is the command line version control tool. TortoiseHg is a gui interface to the tool. TortoiseHg-Nautilus is a plugin for the nautilus file browser.
```
sudo apt-get update
sudo apt-get install tortoisehg tortoisehg-nautilus
```
Clone the repository to the `~/ros/src/` directory
```
cd ~/ros/src/
hg clone https://bitbucket.org/oaklandrobotics/ros_ora17
```

# Build the workspace
This must be done from the root of the workspace. Setting the DCMAKE_BUILD_TYPE to Release makes sure the code will run as fast as possible. Many packages set the build type to release in their CMakeLists.txt if it has not been set.
```
cd ~/ros
catkin_make -DCMAKE_BUILD_TYPE=Release
```
# Download Source Dependencies
```
cd ~/ros
wstool init src
wstool merge -t src src/ros_ora17/ora.rosinstall
wstool update -t src
```
# Update dependencies
```
rosdep install --from-paths src --ignore-src -r
```

# Eclipse Neon
1. Install OpenJDK 8 and gnome-panel `$ sudo apt-get install openjdk-8-jdk gnome-panel`
1. Download Eclipse Neon for Linux http://www.eclipse.org/downloads/download.php?file=/technology/epp/downloads/release/neon/1.RC2/eclipse-cpp-neon-1-RC2-linux-gtk-x86_64.tar.gz and extract it to the desktop.
DO NOT get Eclipse from the Ubuntu Software Center or apt-get. It is an older version with many problems.
1. Eclipse must be run from a terminal to be aware of ROS environmental variables. We will use gnome-panel to make a shortcut on the desktop.
    1. Creater launcher for Eclipse on the desktop `$ gnome-desktop-item-edit ~/Desktop/ --create-new`
    1. Launcher options
        1. Type: Application
        1. Name: Eclipse
        1. Command: bash -i -c "~/Desktop/eclipse/eclipse -vmargs -Xmx2048m"
        1. Icon: Browse for icon.xpm in the eclipse folder
    1. If the shortcut doesn't launch anything, make sure the quotes in the command are actual quotes. You can edit the desktop file with the command `$ gedit ~/Desktop/Eclipse.desktop`
1. Import the C\+\+ formatting template. Window->Preferences->C/C\+\+->CodeStyle->Formatter->Import. Browse for Eclipse_ORA_ROS_format.xml in the folder ~/ros/src/ros_ora17 and select OK.
1. Generate Eclipse project. Repeat for each desired package.  
`$ roscd some_package`  
`$ cmake -G "Eclipse CDT4 - Unix Makefiles" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_ECLIPSE_MAKE_ARGUMENTS=-j8`
1. Open Eclipse and select File->Import...  
Select General->Existing Projects into Workspace  
Browse for ~/ros/src  
Don't check "Copy projects into workspace"  
Select projects to add and click finish  
1. Now you should be able to build the workspace.
1. If debugging is necessary, check the package's CMakeLists.txt. Many packages set the CMAKE_BUILD_TYPE to Release near the top. Temporarily comment this out when debugging. Don't forget to change it back.
