Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/3IfPzIi46S",
      "expanded_url" : "http:\/\/youtu.be\/Ce1ols-lOTU?a",
      "display_url" : "youtu.be\/Ce1ols-lOTU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318161383411826688",
  "text" : "Interesting (@YouTube http:\/\/t.co\/3IfPzIi46S)",
  "id" : 318161383411826688,
  "created_at" : "2013-03-31 00:42:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 6, 14 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/ynhP1sBX21",
      "expanded_url" : "http:\/\/youtu.be\/TyEsb0mvU9Y?a",
      "display_url" : "youtu.be\/TyEsb0mvU9Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318160508475830272",
  "text" : "Cool (@YouTube http:\/\/t.co\/ynhP1sBX21)",
  "id" : 318160508475830272,
  "created_at" : "2013-03-31 00:39:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 12, 20 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/gCx5pRWwCZ",
      "expanded_url" : "http:\/\/youtu.be\/gzArbwZm7Og?a",
      "display_url" : "youtu.be\/gzArbwZm7Og?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318160203772203008",
  "text" : "Oh dang it (@YouTube http:\/\/t.co\/gCx5pRWwCZ)",
  "id" : 318160203772203008,
  "created_at" : "2013-03-31 00:37:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 58, 66 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/GJGpoS1AZW",
      "expanded_url" : "http:\/\/youtu.be\/1IAhDGYlpqY?a",
      "display_url" : "youtu.be\/1IAhDGYlpqY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318159430954913792",
  "text" : "I am Coptic Orthodox Messianican Conservative Republican (@YouTube http:\/\/t.co\/GJGpoS1AZW)",
  "id" : 318159430954913792,
  "created_at" : "2013-03-31 00:34:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 20, 28 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/GJGpoS1AZW",
      "expanded_url" : "http:\/\/youtu.be\/1IAhDGYlpqY?a",
      "display_url" : "youtu.be\/1IAhDGYlpqY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318159121536929792",
  "text" : "Wow, this is viral (@YouTube http:\/\/t.co\/GJGpoS1AZW)",
  "id" : 318159121536929792,
  "created_at" : "2013-03-31 00:33:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 22, 30 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/T6oAgXiEOU",
      "expanded_url" : "http:\/\/youtu.be\/dagfyx49xD4?a",
      "display_url" : "youtu.be\/dagfyx49xD4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318158861733351424",
  "text" : "This is innapropiate (@YouTube http:\/\/t.co\/T6oAgXiEOU)",
  "id" : 318158861733351424,
  "created_at" : "2013-03-31 00:32:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 27, 35 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/T6oAgXiEOU",
      "expanded_url" : "http:\/\/youtu.be\/dagfyx49xD4?a",
      "display_url" : "youtu.be\/dagfyx49xD4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318158739645554689",
  "text" : "Sheldon's worst nightmare (@YouTube http:\/\/t.co\/T6oAgXiEOU)",
  "id" : 318158739645554689,
  "created_at" : "2013-03-31 00:32:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 11, 19 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/tS3i3gzPwU",
      "expanded_url" : "http:\/\/youtu.be\/LdiByuk96xk?a",
      "display_url" : "youtu.be\/LdiByuk96xk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318158198060236801",
  "text" : "Obviously (@YouTube http:\/\/t.co\/tS3i3gzPwU)",
  "id" : 318158198060236801,
  "created_at" : "2013-03-31 00:30:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 7, 15 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ggwxOkcKzN",
      "expanded_url" : "http:\/\/youtu.be\/G4aYRqeNtkg?a",
      "display_url" : "youtu.be\/G4aYRqeNtkg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318157629845286913",
  "text" : "????? (@YouTube http:\/\/t.co\/ggwxOkcKzN)",
  "id" : 318157629845286913,
  "created_at" : "2013-03-31 00:27:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Of8et2x0rL",
      "expanded_url" : "http:\/\/youtu.be\/iOqOPk97TPo?a",
      "display_url" : "youtu.be\/iOqOPk97TPo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318157244032249856",
  "text" : "I believe in Christ (@YouTube http:\/\/t.co\/Of8et2x0rL)",
  "id" : 318157244032249856,
  "created_at" : "2013-03-31 00:26:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 31, 39 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Of8et2x0rL",
      "expanded_url" : "http:\/\/youtu.be\/iOqOPk97TPo?a",
      "display_url" : "youtu.be\/iOqOPk97TPo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318156922593353729",
  "text" : "May be signs of the end times (@YouTube http:\/\/t.co\/Of8et2x0rL)",
  "id" : 318156922593353729,
  "created_at" : "2013-03-31 00:24:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318054036991537153",
  "text" : "Origin gamer username gamer456148, add me in Tiberium Alliances and other games!!!",
  "id" : 318054036991537153,
  "created_at" : "2013-03-30 17:36:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317463459660972032",
  "text" : "My mom is hoping to send me to training and do a test for people with aspergers and savant syndrome. See hopes to find it soon at umich",
  "id" : 317463459660972032,
  "created_at" : "2013-03-29 02:29:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317332942546411521",
  "text" : "Also got 3 DS games",
  "id" : 317332942546411521,
  "created_at" : "2013-03-28 17:50:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317332869053825025",
  "text" : "Just got new Microsoft .net academic software for $17.34",
  "id" : 317332869053825025,
  "created_at" : "2013-03-28 17:50:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/6ro28lZ6oK",
      "expanded_url" : "http:\/\/sdrv.ms\/16gxJHB",
      "display_url" : "sdrv.ms\/16gxJHB"
    } ]
  },
  "geo" : { },
  "id_str" : "316752728380542976",
  "text" : "Publish America Acceptance Letter http:\/\/t.co\/6ro28lZ6oK",
  "id" : 316752728380542976,
  "created_at" : "2013-03-27 03:25:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 33, 41 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/gODxbZPmi7",
      "expanded_url" : "http:\/\/youtu.be\/ncPLnmIMsCs?a",
      "display_url" : "youtu.be\/ncPLnmIMsCs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "314364901411934208",
  "text" : "God Bless You Brother in Christ (@YouTube http:\/\/t.co\/gODxbZPmi7)",
  "id" : 314364901411934208,
  "created_at" : "2013-03-20 13:16:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 15, 23 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/gODxbZPmi7",
      "expanded_url" : "http:\/\/youtu.be\/ncPLnmIMsCs?a",
      "display_url" : "youtu.be\/ncPLnmIMsCs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "314364838015016961",
  "text" : "No it is not. (@YouTube http:\/\/t.co\/gODxbZPmi7)",
  "id" : 314364838015016961,
  "created_at" : "2013-03-20 13:16:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/gODxbZPmi7",
      "expanded_url" : "http:\/\/youtu.be\/ncPLnmIMsCs?a",
      "display_url" : "youtu.be\/ncPLnmIMsCs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "313838304292397056",
  "text" : "Amazing Miracle, Face Appears Next to Image of Jesus: http:\/\/t.co\/gODxbZPmi7 via @YouTube",
  "id" : 313838304292397056,
  "created_at" : "2013-03-19 02:24:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 58, 66 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/iltu76Nn74",
      "expanded_url" : "http:\/\/youtu.be\/bPvAQxZsgpQ?a",
      "display_url" : "youtu.be\/bPvAQxZsgpQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "313075071063314432",
  "text" : "Watching again, I watched this video like so many times. (@YouTube http:\/\/t.co\/iltu76Nn74)",
  "id" : 313075071063314432,
  "created_at" : "2013-03-16 23:51:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/k3Ah49pFPn",
      "expanded_url" : "http:\/\/youtu.be\/P8WMAoFRTIM?a",
      "display_url" : "youtu.be\/P8WMAoFRTIM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312757068497043456",
  "text" : "Everyone watch this http:\/\/t.co\/k3Ah49pFPn",
  "id" : 312757068497043456,
  "created_at" : "2013-03-16 02:47:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Uln4ALWwPW",
      "expanded_url" : "http:\/\/youtu.be\/25rAE-WU_RM?a",
      "display_url" : "youtu.be\/25rAE-WU_RM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312748705709187072",
  "text" : "This is sick (@YouTube http:\/\/t.co\/Uln4ALWwPW)",
  "id" : 312748705709187072,
  "created_at" : "2013-03-16 02:14:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 16, 24 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/iltu76Nn74",
      "expanded_url" : "http:\/\/youtu.be\/bPvAQxZsgpQ?a",
      "display_url" : "youtu.be\/bPvAQxZsgpQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312748161506627584",
  "text" : "Watching again (@YouTube http:\/\/t.co\/iltu76Nn74)",
  "id" : 312748161506627584,
  "created_at" : "2013-03-16 02:12:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 89, 97 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/x40kD2Naoc",
      "expanded_url" : "http:\/\/youtu.be\/SQL7QLHevcE?a",
      "display_url" : "youtu.be\/SQL7QLHevcE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312747303914065920",
  "text" : "That was so funny, LOL, you should have seen rick's face when his son left with the car (@YouTube http:\/\/t.co\/x40kD2Naoc)",
  "id" : 312747303914065920,
  "created_at" : "2013-03-16 02:09:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/x40kD2Naoc",
      "expanded_url" : "http:\/\/youtu.be\/SQL7QLHevcE?a",
      "display_url" : "youtu.be\/SQL7QLHevcE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312747059201581057",
  "text" : "I liked a @YouTube video http:\/\/t.co\/x40kD2Naoc Pawn Stars: Bugaboo",
  "id" : 312747059201581057,
  "created_at" : "2013-03-16 02:08:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/YRSCAweRGo",
      "expanded_url" : "http:\/\/youtu.be\/l2j7uzyQH48?a",
      "display_url" : "youtu.be\/l2j7uzyQH48?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312744195091726337",
  "text" : "I liked a @YouTube video http:\/\/t.co\/YRSCAweRGo My top 5 favorite pawn stars moments",
  "id" : 312744195091726337,
  "created_at" : "2013-03-16 01:56:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 7, 15 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/jpFksMeUpX",
      "expanded_url" : "http:\/\/youtu.be\/FlJ-IqQP1RU?a",
      "display_url" : "youtu.be\/FlJ-IqQP1RU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312739658142449664",
  "text" : "FAKE, (@YouTube http:\/\/t.co\/jpFksMeUpX)",
  "id" : 312739658142449664,
  "created_at" : "2013-03-16 01:38:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/J9n1K5djWx",
      "expanded_url" : "http:\/\/youtu.be\/qF7Gt13lj08?a",
      "display_url" : "youtu.be\/qF7Gt13lj08?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312736536712077312",
  "text" : "I liked a @YouTube video http:\/\/t.co\/J9n1K5djWx illuminati Alien Lie they are fallen angels not aliens + katy perry shows picture of",
  "id" : 312736536712077312,
  "created_at" : "2013-03-16 01:26:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/D4X6UwLzgd",
      "expanded_url" : "http:\/\/youtu.be\/q8PyvqsuYlU?a",
      "display_url" : "youtu.be\/q8PyvqsuYlU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312733794337685506",
  "text" : "I liked a @YouTube video http:\/\/t.co\/D4X6UwLzgd John Fogerty Susie Q, I Put A Spell On You 1998 XviD AC3",
  "id" : 312733794337685506,
  "created_at" : "2013-03-16 01:15:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 22, 30 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/iltu76Nn74",
      "expanded_url" : "http:\/\/youtu.be\/bPvAQxZsgpQ?a",
      "display_url" : "youtu.be\/bPvAQxZsgpQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312733096019640322",
  "text" : "The voice is angelic (@YouTube http:\/\/t.co\/iltu76Nn74)",
  "id" : 312733096019640322,
  "created_at" : "2013-03-16 01:12:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/iltu76Nn74",
      "expanded_url" : "http:\/\/youtu.be\/bPvAQxZsgpQ?a",
      "display_url" : "youtu.be\/bPvAQxZsgpQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312732011557183488",
  "text" : "Upload more of these songs (@YouTube http:\/\/t.co\/iltu76Nn74)",
  "id" : 312732011557183488,
  "created_at" : "2013-03-16 01:08:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Ricardo Valdez",
      "screen_name" : "valdezalcantara",
      "indices" : [ 30, 46 ],
      "id_str" : "113722880",
      "id" : 113722880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/iltu76Nn74",
      "expanded_url" : "http:\/\/youtu.be\/bPvAQxZsgpQ?a",
      "display_url" : "youtu.be\/bPvAQxZsgpQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312731656601620481",
  "text" : "I liked a @YouTube video from @valdezalcantara http:\/\/t.co\/iltu76Nn74 Luciano Pavarotti - Ave Maria",
  "id" : 312731656601620481,
  "created_at" : "2013-03-16 01:06:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 47, 55 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/6P0QyyfHPe",
      "expanded_url" : "http:\/\/youtu.be\/DvlTuBnpKpc?a",
      "display_url" : "youtu.be\/DvlTuBnpKpc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312391653891649536",
  "text" : "The meaning behind the song is just beautiful (@YouTube http:\/\/t.co\/6P0QyyfHPe)",
  "id" : 312391653891649536,
  "created_at" : "2013-03-15 02:35:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/6wDJh30fLm",
      "expanded_url" : "http:\/\/youtu.be\/mcFHVhhwgq8?a",
      "display_url" : "youtu.be\/mcFHVhhwgq8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312388069145858049",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/6wDJh30fLm Orthodox Miracles Part 2",
  "id" : 312388069145858049,
  "created_at" : "2013-03-15 02:21:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/q1X1zgnCQp",
      "expanded_url" : "http:\/\/youtu.be\/uV6eQLLjwS4?a",
      "display_url" : "youtu.be\/uV6eQLLjwS4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312387665125335040",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/q1X1zgnCQp Orthodox Miracles Part 1",
  "id" : 312387665125335040,
  "created_at" : "2013-03-15 02:19:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/821q2BqtqQ",
      "expanded_url" : "http:\/\/youtu.be\/WssDtGZ0Ugw?a",
      "display_url" : "youtu.be\/WssDtGZ0Ugw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312385982555099136",
  "text" : "Great video (@YouTube http:\/\/t.co\/821q2BqtqQ)",
  "id" : 312385982555099136,
  "created_at" : "2013-03-15 02:13:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 5, 13 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/vInKnfrAQN",
      "expanded_url" : "http:\/\/youtu.be\/0kL2MfiebTI?a",
      "display_url" : "youtu.be\/0kL2MfiebTI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312385648155820032",
  "text" : "Wow (@YouTube http:\/\/t.co\/vInKnfrAQN)",
  "id" : 312385648155820032,
  "created_at" : "2013-03-15 02:11:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/OXvDymoxmq",
      "expanded_url" : "http:\/\/youtu.be\/gvgd4cZXoyk?a",
      "display_url" : "youtu.be\/gvgd4cZXoyk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312385388423561216",
  "text" : "Quite Interesting (@YouTube http:\/\/t.co\/OXvDymoxmq)",
  "id" : 312385388423561216,
  "created_at" : "2013-03-15 02:10:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cherrygirl",
      "screen_name" : "MayaCherry",
      "indices" : [ 0, 11 ],
      "id_str" : "50137679",
      "id" : 50137679
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/KAhsukBfYx",
      "expanded_url" : "http:\/\/youtu.be\/CxIhUsFwixk?a",
      "display_url" : "youtu.be\/CxIhUsFwixk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312385165462749184",
  "in_reply_to_user_id" : 50137679,
  "text" : "@MayaCherry Heartily, thanks you are a great youtube user and God bless You (@YouTube http:\/\/t.co\/KAhsukBfYx)",
  "id" : 312385165462749184,
  "created_at" : "2013-03-15 02:10:01 +0000",
  "in_reply_to_screen_name" : "MayaCherry",
  "in_reply_to_user_id_str" : "50137679",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/6DZNBXkAW0",
      "expanded_url" : "http:\/\/youtu.be\/AyBDs8JpEa8?a",
      "display_url" : "youtu.be\/AyBDs8JpEa8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312384699651739648",
  "text" : "God is trying to do everything to show he exists and save helpless souls, yet some people stay (@YouTube http:\/\/t.co\/6DZNBXkAW0)",
  "id" : 312384699651739648,
  "created_at" : "2013-03-15 02:08:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ihzstOmLxC",
      "expanded_url" : "http:\/\/youtu.be\/mI7_RKgq9tU?a",
      "display_url" : "youtu.be\/mI7_RKgq9tU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312383952344207360",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ihzstOmLxC Sign of the crucified Christ above Russia",
  "id" : 312383952344207360,
  "created_at" : "2013-03-15 02:05:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 26, 34 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ODt1fKNy3V",
      "expanded_url" : "http:\/\/youtu.be\/fxkngzG41ZE?a",
      "display_url" : "youtu.be\/fxkngzG41ZE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312383590354804736",
  "text" : "Yes, very true my friend (@YouTube http:\/\/t.co\/ODt1fKNy3V)",
  "id" : 312383590354804736,
  "created_at" : "2013-03-15 02:03:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ODt1fKNy3V",
      "expanded_url" : "http:\/\/youtu.be\/fxkngzG41ZE?a",
      "display_url" : "youtu.be\/fxkngzG41ZE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312383493516718080",
  "text" : "I liked a @YouTube video http:\/\/t.co\/ODt1fKNy3V Bluebeam, Jesus crucifix in the sky. Prepare for the fake alien invasion in 2012",
  "id" : 312383493516718080,
  "created_at" : "2013-03-15 02:03:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/6ZLNAFzi7u",
      "expanded_url" : "http:\/\/youtu.be\/OEX6JHznqwA?a",
      "display_url" : "youtu.be\/OEX6JHznqwA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312382377353682944",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/6ZLNAFzi7u The REAL Face of Jesus Christ- Two great miracles for our World",
  "id" : 312382377353682944,
  "created_at" : "2013-03-15 01:58:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/jnKS8mkRic",
      "expanded_url" : "http:\/\/youtu.be\/gLc7NjLCrPo?a",
      "display_url" : "youtu.be\/gLc7NjLCrPo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312380659605856257",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/jnKS8mkRic Coptic Hymn Salib Yaso3",
  "id" : 312380659605856257,
  "created_at" : "2013-03-15 01:52:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/jnKS8mkRic",
      "expanded_url" : "http:\/\/youtu.be\/gLc7NjLCrPo?a",
      "display_url" : "youtu.be\/gLc7NjLCrPo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312380637405405184",
  "text" : "I liked a @YouTube video http:\/\/t.co\/jnKS8mkRic Coptic Hymn Salib Yaso3",
  "id" : 312380637405405184,
  "created_at" : "2013-03-15 01:52:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ZLPqpwfF1K",
      "expanded_url" : "http:\/\/youtu.be\/0oLlU5KGoWk?a",
      "display_url" : "youtu.be\/0oLlU5KGoWk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312379446986436608",
  "text" : "I liked a @YouTube video http:\/\/t.co\/ZLPqpwfF1K New Year 2013 Message",
  "id" : 312379446986436608,
  "created_at" : "2013-03-15 01:47:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ZLPqpwfF1K",
      "expanded_url" : "http:\/\/youtu.be\/0oLlU5KGoWk?a",
      "display_url" : "youtu.be\/0oLlU5KGoWk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312379391458045952",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ZLPqpwfF1K New Year 2013 Message",
  "id" : 312379391458045952,
  "created_at" : "2013-03-15 01:47:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/X1BFulx2FT",
      "expanded_url" : "http:\/\/youtu.be\/AD44-ZoAkG8?a",
      "display_url" : "youtu.be\/AD44-ZoAkG8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312378963102162944",
  "text" : "I liked a @YouTube video http:\/\/t.co\/X1BFulx2FT Orthodox Divine Liturgy-Cherubic Hymn.\u03A7\u03B5\u03C1\u03BF\u03C5\u03B2\u03B9\u03BA\u03CC\u03C2 \u038E\u03BC\u03BD\u03BF\u03C2",
  "id" : 312378963102162944,
  "created_at" : "2013-03-15 01:45:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/X1BFulx2FT",
      "expanded_url" : "http:\/\/youtu.be\/AD44-ZoAkG8?a",
      "display_url" : "youtu.be\/AD44-ZoAkG8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312378961772572673",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/X1BFulx2FT Orthodox Divine Liturgy-Cherubic Hymn.\u03A7\u03B5\u03C1\u03BF\u03C5\u03B2\u03B9\u03BA\u03CC\u03C2 \u038E\u03BC\u03BD\u03BF\u03C2",
  "id" : 312378961772572673,
  "created_at" : "2013-03-15 01:45:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 18, 26 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/xFqsfBLmjL",
      "expanded_url" : "http:\/\/youtu.be\/TBWSO901AgE?a",
      "display_url" : "youtu.be\/TBWSO901AgE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312378854499028992",
  "text" : "Beautifully said (@YouTube http:\/\/t.co\/xFqsfBLmjL)",
  "id" : 312378854499028992,
  "created_at" : "2013-03-15 01:44:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/xFqsfBLmjL",
      "expanded_url" : "http:\/\/youtu.be\/TBWSO901AgE?a",
      "display_url" : "youtu.be\/TBWSO901AgE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312378679000969217",
  "text" : "I liked a @YouTube video http:\/\/t.co\/xFqsfBLmjL Shere Maria Tee-oro-coptic-\u0627\u0644\u0633\u0644\u0627\u0645 \u0644\u0645\u0631\u064A\u0645 \u0627\u0644\u0645\u0644\u0643\u0629-bekhit",
  "id" : 312378679000969217,
  "created_at" : "2013-03-15 01:44:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/xFqsfBLmjL",
      "expanded_url" : "http:\/\/youtu.be\/TBWSO901AgE?a",
      "display_url" : "youtu.be\/TBWSO901AgE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312378555986235392",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/xFqsfBLmjL Shere Maria Tee-oro-coptic-\u0627\u0644\u0633\u0644\u0627\u0645 \u0644\u0645\u0631\u064A\u0645 \u0627\u0644\u0645\u0644\u0643\u0629-bekhit",
  "id" : 312378555986235392,
  "created_at" : "2013-03-15 01:43:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/xmtS4i4h7W",
      "expanded_url" : "http:\/\/youtu.be\/eYW1AYxjk-w?a",
      "display_url" : "youtu.be\/eYW1AYxjk-w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312378263815208960",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/xmtS4i4h7W Enthronement Liturgy of H.H. Pope Tawadros II",
  "id" : 312378263815208960,
  "created_at" : "2013-03-15 01:42:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 12, 20 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/KevN8ymXNu",
      "expanded_url" : "http:\/\/youtu.be\/povomwhfZas?a",
      "display_url" : "youtu.be\/povomwhfZas?a"
    } ]
  },
  "geo" : { },
  "id_str" : "312031459684786176",
  "text" : "That is me (@YouTube http:\/\/t.co\/KevN8ymXNu)",
  "id" : 312031459684786176,
  "created_at" : "2013-03-14 02:44:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 86, 94 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/dhMv4fi2on",
      "expanded_url" : "http:\/\/youtu.be\/Pb1tknG58D4?a",
      "display_url" : "youtu.be\/Pb1tknG58D4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "311136219956404226",
  "text" : "I never questioned the reasons behind religion. However, I do notice that their is a (@YouTube http:\/\/t.co\/dhMv4fi2on)",
  "id" : 311136219956404226,
  "created_at" : "2013-03-11 15:27:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/dhMv4fi2on",
      "expanded_url" : "http:\/\/youtu.be\/Pb1tknG58D4?a",
      "display_url" : "youtu.be\/Pb1tknG58D4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "311134818802999296",
  "text" : "Why thank you, my IQ may be highest. However, intellect to me is a state of mind. Hard work, (@YouTube http:\/\/t.co\/dhMv4fi2on)",
  "id" : 311134818802999296,
  "created_at" : "2013-03-11 15:21:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 6, 14 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/dhMv4fi2on",
      "expanded_url" : "http:\/\/youtu.be\/Pb1tknG58D4?a",
      "display_url" : "youtu.be\/Pb1tknG58D4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "311133689704742913",
  "text" : "Sure (@YouTube http:\/\/t.co\/dhMv4fi2on)",
  "id" : 311133689704742913,
  "created_at" : "2013-03-11 15:17:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/dhMv4fi2on",
      "expanded_url" : "http:\/\/youtu.be\/Pb1tknG58D4?a",
      "display_url" : "youtu.be\/Pb1tknG58D4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "311133665210015744",
  "text" : "Okay, but as long as it isn't offensive (@YouTube http:\/\/t.co\/dhMv4fi2on)",
  "id" : 311133665210015744,
  "created_at" : "2013-03-11 15:17:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/bnZm4mROS0",
      "expanded_url" : "http:\/\/youtu.be\/hBW4S9xcTOk?a",
      "display_url" : "youtu.be\/hBW4S9xcTOk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "310585240823414785",
  "text" : "I liked a @YouTube video http:\/\/t.co\/bnZm4mROS0 12 Year Old Genius Jacob Barnett on Glenn Beck",
  "id" : 310585240823414785,
  "created_at" : "2013-03-10 02:57:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nasir Bahrami",
      "screen_name" : "Nasir",
      "indices" : [ 0, 6 ],
      "id_str" : "6161522",
      "id" : 6161522
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/GnfDBizPZw",
      "expanded_url" : "http:\/\/youtu.be\/MGtihEa5BCU?a",
      "display_url" : "youtu.be\/MGtihEa5BCU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "310550950467211265",
  "in_reply_to_user_id" : 6161522,
  "text" : "@Nasir Germain, I proved Einstein wrong first, also we are not here to brag. Intellect in only (@YouTube http:\/\/t.co\/GnfDBizPZw)",
  "id" : 310550950467211265,
  "created_at" : "2013-03-10 00:41:31 +0000",
  "in_reply_to_screen_name" : "Nasir",
  "in_reply_to_user_id_str" : "6161522",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/O1SRoetaYQ",
      "expanded_url" : "http:\/\/youtu.be\/6Q8ruZyKzcs?a",
      "display_url" : "youtu.be\/6Q8ruZyKzcs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "310048092323991555",
  "text" : "I liked a @YouTube video http:\/\/t.co\/O1SRoetaYQ Entrepreneur IQ Quiz Video.wmv",
  "id" : 310048092323991555,
  "created_at" : "2013-03-08 15:23:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 16, 24 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Qw7P0Sd8RU",
      "expanded_url" : "http:\/\/youtu.be\/9ylxRvS8-UY?a",
      "display_url" : "youtu.be\/9ylxRvS8-UY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309808886523785216",
  "text" : "This is awsome (@YouTube http:\/\/t.co\/Qw7P0Sd8RU)",
  "id" : 309808886523785216,
  "created_at" : "2013-03-07 23:32:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Qw7P0Sd8RU",
      "expanded_url" : "http:\/\/youtu.be\/9ylxRvS8-UY?a",
      "display_url" : "youtu.be\/9ylxRvS8-UY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309807739666825216",
  "text" : "I am Andrew Magdy Kamal, and I am your biggest fan for Man vs. Ball (@YouTube http:\/\/t.co\/Qw7P0Sd8RU)",
  "id" : 309807739666825216,
  "created_at" : "2013-03-07 23:28:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "tommee profitt",
      "screen_name" : "tommeeprofitt",
      "indices" : [ 30, 44 ],
      "id_str" : "23875390",
      "id" : 23875390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Qw7P0Sd8RU",
      "expanded_url" : "http:\/\/youtu.be\/9ylxRvS8-UY?a",
      "display_url" : "youtu.be\/9ylxRvS8-UY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309807508032200704",
  "text" : "I liked a @YouTube video from @tommeeprofitt http:\/\/t.co\/Qw7P0Sd8RU MAN VS BALL 6 (short film by Tommee Profitt)",
  "id" : 309807508032200704,
  "created_at" : "2013-03-07 23:27:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/xPRZnpHg5H",
      "expanded_url" : "http:\/\/youtu.be\/k65SVIOxRHQ?a",
      "display_url" : "youtu.be\/k65SVIOxRHQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309805074199244800",
  "text" : "I liked a @YouTube video http:\/\/t.co\/xPRZnpHg5H Suicidal Girl Makes an Unforgettable Video Everyone Should See - TheGodVine",
  "id" : 309805074199244800,
  "created_at" : "2013-03-07 23:17:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/U66UyoOWGu",
      "expanded_url" : "http:\/\/youtu.be\/HpGOKsz5g0s?a",
      "display_url" : "youtu.be\/HpGOKsz5g0s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309752489270444032",
  "text" : "I liked a @YouTube video http:\/\/t.co\/U66UyoOWGu My Edited Video",
  "id" : 309752489270444032,
  "created_at" : "2013-03-07 19:48:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 89, 97 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/vf1orCyjou",
      "expanded_url" : "http:\/\/youtu.be\/9Hpsjd_kA-A?a",
      "display_url" : "youtu.be\/9Hpsjd_kA-A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309752305140498433",
  "text" : "I came up with the idea that the reason Einstein's theory is wrong is because it didn't (@YouTube http:\/\/t.co\/vf1orCyjou)",
  "id" : 309752305140498433,
  "created_at" : "2013-03-07 19:47:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 23, 31 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/AtSOT6N35N",
      "expanded_url" : "http:\/\/youtu.be\/5twCeUOhJ5Q?a",
      "display_url" : "youtu.be\/5twCeUOhJ5Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309436759660453888",
  "text" : "He is coptic orthodox (@YouTube http:\/\/t.co\/AtSOT6N35N)",
  "id" : 309436759660453888,
  "created_at" : "2013-03-06 22:54:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/AtSOT6N35N",
      "expanded_url" : "http:\/\/youtu.be\/5twCeUOhJ5Q?a",
      "display_url" : "youtu.be\/5twCeUOhJ5Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309436687832981506",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/AtSOT6N35N Father Makari Yunan's exorcisms (2)",
  "id" : 309436687832981506,
  "created_at" : "2013-03-06 22:53:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/AtSOT6N35N",
      "expanded_url" : "http:\/\/youtu.be\/5twCeUOhJ5Q?a",
      "display_url" : "youtu.be\/5twCeUOhJ5Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "309436189415469058",
  "text" : "I liked a @YouTube video http:\/\/t.co\/AtSOT6N35N Father Makari Yunan's exorcisms (2)",
  "id" : 309436189415469058,
  "created_at" : "2013-03-06 22:51:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 43, 51 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/KrcoRSUk3p",
      "expanded_url" : "http:\/\/youtu.be\/oA4eMOua_co?a",
      "display_url" : "youtu.be\/oA4eMOua_co?a"
    } ]
  },
  "geo" : { },
  "id_str" : "307586896949805056",
  "text" : "This is a famous painting by Robert Chang (@YouTube http:\/\/t.co\/KrcoRSUk3p)",
  "id" : 307586896949805056,
  "created_at" : "2013-03-01 20:23:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/qZHrPrIsEi",
      "expanded_url" : "http:\/\/youtu.be\/aKxbKE3_53M?a",
      "display_url" : "youtu.be\/aKxbKE3_53M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "307580002008981504",
  "text" : "Now I know why people get haircuts at home (@YouTube http:\/\/t.co\/qZHrPrIsEi)",
  "id" : 307580002008981504,
  "created_at" : "2013-03-01 19:56:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]