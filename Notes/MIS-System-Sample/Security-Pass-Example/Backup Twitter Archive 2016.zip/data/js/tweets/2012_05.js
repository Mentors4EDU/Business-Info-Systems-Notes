Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GEGarages",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/zsuat5eg",
      "expanded_url" : "http:\/\/andsocialrew.wall.fm",
      "display_url" : "andsocialrew.wall.fm"
    }, {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/d3bA2e68",
      "expanded_url" : "http:\/\/ge.quirky.com",
      "display_url" : "ge.quirky.com"
    } ]
  },
  "geo" : { },
  "id_str" : "198520192941309952",
  "text" : "http:\/\/t.co\/zsuat5eg ,it will be the next big social networking and chatting app RT to vote! http:\/\/t.co\/d3bA2e68 #GEGarages",
  "id" : 198520192941309952,
  "created_at" : "2012-05-04 21:11:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]