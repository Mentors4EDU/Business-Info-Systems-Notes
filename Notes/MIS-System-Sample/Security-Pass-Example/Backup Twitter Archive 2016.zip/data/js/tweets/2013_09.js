Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384352096537288705",
  "text" : "drove a Pontiac g6 with instructor and mom, lol =D",
  "id" : 384352096537288705,
  "created_at" : "2013-09-29 16:20:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384124510502653953",
  "text" : "Kids, lol, I said lids, like what the fudge",
  "id" : 384124510502653953,
  "created_at" : "2013-09-29 01:16:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384124187901968384",
  "text" : "Little lids are so cute ;)",
  "id" : 384124187901968384,
  "created_at" : "2013-09-29 01:15:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/demjjLslLG",
      "expanded_url" : "http:\/\/sdrv.ms\/19KsxwB",
      "display_url" : "sdrv.ms\/19KsxwB"
    } ]
  },
  "geo" : { },
  "id_str" : "384124119580962816",
  "text" : "For the record I won by more points Mark, lol Lydia's face http:\/\/t.co\/demjjLslLG",
  "id" : 384124119580962816,
  "created_at" : "2013-09-29 01:15:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/TDfKlZJ429",
      "expanded_url" : "http:\/\/sdrv.ms\/19dTEOh",
      "display_url" : "sdrv.ms\/19dTEOh"
    } ]
  },
  "geo" : { },
  "id_str" : "384065356840861696",
  "text" : "Lol look so cool http:\/\/t.co\/TDfKlZJ429",
  "id" : 384065356840861696,
  "created_at" : "2013-09-28 21:21:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383987023285329920",
  "text" : "Ride on, so scared on expressway",
  "id" : 383987023285329920,
  "created_at" : "2013-09-28 16:10:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383986870163873792",
  "text" : "Drove a Pontiac g6 with Fallon and different instructor, yesterday drove with Lisa Rinke, lol",
  "id" : 383986870163873792,
  "created_at" : "2013-09-28 16:09:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383777894205784064",
  "text" : "Drove Pontiac g6 then went to tutoring, long day, boring and rough end day :\/",
  "id" : 383777894205784064,
  "created_at" : "2013-09-28 02:19:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383440160605876224",
  "text" : "Bad day :(",
  "id" : 383440160605876224,
  "created_at" : "2013-09-27 03:57:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383410832089968640",
  "text" : "Today was rough, drove pontiac g6 with mad person, went to drivers ed, them went home to eat, heard bad news :(",
  "id" : 383410832089968640,
  "created_at" : "2013-09-27 02:00:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/7LtDYWoFYI",
      "expanded_url" : "http:\/\/sdrv.ms\/19B9FQl",
      "display_url" : "sdrv.ms\/19B9FQl"
    } ]
  },
  "geo" : { },
  "id_str" : "383105207699529728",
  "text" : "Beauty indeed http:\/\/t.co\/7LtDYWoFYI",
  "id" : 383105207699529728,
  "created_at" : "2013-09-26 05:46:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383041858622193664",
  "text" : "Melted garlic goat cheese on pita, yum",
  "id" : 383041858622193664,
  "created_at" : "2013-09-26 01:34:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383036756008128512",
  "text" : "Gave a gal my number :p",
  "id" : 383036756008128512,
  "created_at" : "2013-09-26 01:14:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383036609064882176",
  "text" : "Drove Pontiac g6, with sis and mad instructor, then went to drivers ed, tough day",
  "id" : 383036609064882176,
  "created_at" : "2013-09-26 01:13:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/wRTw8pa4EB",
      "expanded_url" : "http:\/\/sdrv.ms\/18XxeRa",
      "display_url" : "sdrv.ms\/18XxeRa"
    } ]
  },
  "geo" : { },
  "id_str" : "382697029581176832",
  "text" : "Had two pieces of naan, gonna have two more http:\/\/t.co\/wRTw8pa4EB",
  "id" : 382697029581176832,
  "created_at" : "2013-09-25 02:44:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382669634878840832",
  "text" : "Went to drivers ed yesterday and today, people need to stop hugging me, lol",
  "id" : 382669634878840832,
  "created_at" : "2013-09-25 00:55:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Xf7mATYF6v",
      "expanded_url" : "http:\/\/sdrv.ms\/1dF1V31",
      "display_url" : "sdrv.ms\/1dF1V31"
    } ]
  },
  "geo" : { },
  "id_str" : "382306812831477760",
  "text" : "Like an Indian remember geekslayer73, lol http:\/\/t.co\/Xf7mATYF6v",
  "id" : 382306812831477760,
  "created_at" : "2013-09-24 00:53:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Dl9WZFbiYz",
      "expanded_url" : "http:\/\/sdrv.ms\/16CufxG",
      "display_url" : "sdrv.ms\/16CufxG"
    } ]
  },
  "geo" : { },
  "id_str" : "382252167710928896",
  "text" : "Tag stuff with wikitude http:\/\/t.co\/Dl9WZFbiYz",
  "id" : 382252167710928896,
  "created_at" : "2013-09-23 21:16:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/XoJhV2LkwS",
      "expanded_url" : "http:\/\/sdrv.ms\/1aZUUJ0",
      "display_url" : "sdrv.ms\/1aZUUJ0"
    } ]
  },
  "geo" : { },
  "id_str" : "382251856862670848",
  "text" : "Epic XD augmented reality http:\/\/t.co\/XoJhV2LkwS",
  "id" : 382251856862670848,
  "created_at" : "2013-09-23 21:15:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/9yqOVDJuWI",
      "expanded_url" : "http:\/\/sdrv.ms\/1aiZFwk",
      "display_url" : "sdrv.ms\/1aiZFwk"
    } ]
  },
  "geo" : { },
  "id_str" : "382251465831882752",
  "text" : "Look what I can do http:\/\/t.co\/9yqOVDJuWI",
  "id" : 382251465831882752,
  "created_at" : "2013-09-23 21:13:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/m69MPF9Dp4",
      "expanded_url" : "http:\/\/sdrv.ms\/16ub5cv",
      "display_url" : "sdrv.ms\/16ub5cv"
    } ]
  },
  "geo" : { },
  "id_str" : "382251372265365505",
  "text" : "Augmented reality camera is so much fun on the Nokia Lumia http:\/\/t.co\/m69MPF9Dp4",
  "id" : 382251372265365505,
  "created_at" : "2013-09-23 21:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382232008182624256\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/f9S39QlWuk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU31_H3CcAMSZ09.png",
      "id_str" : "382232008186818563",
      "id" : 382232008186818563,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU31_H3CcAMSZ09.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/f9S39QlWuk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382232008182624256",
  "text" : "Domino attacks http:\/\/t.co\/f9S39QlWuk",
  "id" : 382232008182624256,
  "created_at" : "2013-09-23 19:56:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382230273217138689\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/UEr6moysp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU30aIoCEAANoVi.png",
      "id_str" : "382230273225527296",
      "id" : 382230273225527296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU30aIoCEAANoVi.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UEr6moysp5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382230273217138689",
  "text" : "Violence, is only the answer in video games, war, boxing, movies, self defense, lol http:\/\/t.co\/UEr6moysp5",
  "id" : 382230273217138689,
  "created_at" : "2013-09-23 19:49:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382229270648471552\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/ircjkJ81sK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3zfxxCQAAopzx.png",
      "id_str" : "382229270656860160",
      "id" : 382229270656860160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3zfxxCQAAopzx.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ircjkJ81sK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382229270648471552",
  "text" : "It was too posible http:\/\/t.co\/ircjkJ81sK",
  "id" : 382229270648471552,
  "created_at" : "2013-09-23 19:45:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382229019782950913\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/BkuhFGZTLa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3zRLNCMAAlFl1.png",
      "id_str" : "382229019787145216",
      "id" : 382229019787145216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3zRLNCMAAlFl1.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BkuhFGZTLa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382229019782950913",
  "text" : "Ouchie http:\/\/t.co\/BkuhFGZTLa",
  "id" : 382229019782950913,
  "created_at" : "2013-09-23 19:44:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382228530198626304\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/DZeVfL2bMx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3y0rXCQAAdCOz.png",
      "id_str" : "382228530202820608",
      "id" : 382228530202820608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3y0rXCQAAdCOz.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DZeVfL2bMx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382228530198626304",
  "text" : "That was easy http:\/\/t.co\/DZeVfL2bMx",
  "id" : 382228530198626304,
  "created_at" : "2013-09-23 19:42:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382227894656720896\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/7wHxK2JOyU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3yPryCYAINrGe.png",
      "id_str" : "382227894660915202",
      "id" : 382227894660915202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3yPryCYAINrGe.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7wHxK2JOyU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382227894656720896",
  "text" : "It wasn't one star bad http:\/\/t.co\/7wHxK2JOyU",
  "id" : 382227894656720896,
  "created_at" : "2013-09-23 19:40:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382227673793044480\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/tv309O3O8q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3yC1ACIAAJIgs.png",
      "id_str" : "382227673797238784",
      "id" : 382227673797238784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3yC1ACIAAJIgs.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tv309O3O8q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382227673793044480",
  "text" : "Flag's broken http:\/\/t.co\/tv309O3O8q",
  "id" : 382227673793044480,
  "created_at" : "2013-09-23 19:39:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/382226669747961857\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/dBIkVJDpnx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3xIYpCAAENUlv.png",
      "id_str" : "382226669752156161",
      "id" : 382226669752156161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3xIYpCAAENUlv.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dBIkVJDpnx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382226669747961857",
  "text" : "Okay http:\/\/t.co\/dBIkVJDpnx",
  "id" : 382226669747961857,
  "created_at" : "2013-09-23 19:35:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382193489020059648",
  "text" : "I love poetry, you know I am a poet, a revolution poetry is.",
  "id" : 382193489020059648,
  "created_at" : "2013-09-23 17:23:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/0xnXvIUTiW",
      "expanded_url" : "http:\/\/ganer456148.blogspot.com",
      "display_url" : "ganer456148.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "382193414541819904",
  "text" : "LOL, look at all the links I am posting that leads to some poetry, also see here: http:\/\/t.co\/0xnXvIUTiW",
  "id" : 382193414541819904,
  "created_at" : "2013-09-23 17:23:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rZIepjbtzJ",
      "expanded_url" : "http:\/\/vixra.org\/pdf\/1301.0097v1.pdf",
      "display_url" : "vixra.org\/pdf\/1301.0097v\u2026"
    }, {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/jBqS0P7OOj",
      "expanded_url" : "http:\/\/gamer456148.blogspot.com",
      "display_url" : "gamer456148.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "382193245389733888",
  "text" : "http:\/\/t.co\/rZIepjbtzJ, http:\/\/t.co\/jBqS0P7OOj",
  "id" : 382193245389733888,
  "created_at" : "2013-09-23 17:22:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/i4mIPjnx1S",
      "expanded_url" : "http:\/\/www.reverbnation.com\/artist_2323367\/bio",
      "display_url" : "reverbnation.com\/artist_2323367\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382192851246804994",
  "text" : "http:\/\/t.co\/i4mIPjnx1S",
  "id" : 382192851246804994,
  "created_at" : "2013-09-23 17:20:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/SOPeToqLmK",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/127Pd934dWI5myRuh-qLFqeqT7pp_kWwC7OWfFwPkp6w\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/127\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382192700574806016",
  "text" : "See my poetry, https:\/\/t.co\/SOPeToqLmK",
  "id" : 382192700574806016,
  "created_at" : "2013-09-23 17:20:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381528961479880705",
  "text" : "Had a gyro at Dimitris, also had French onion soup, and fries, yum",
  "id" : 381528961479880705,
  "created_at" : "2013-09-21 21:22:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381171821829058560",
  "text" : "Yesterday driver's ed was so boring, lol, glad I don't have driver's ed today",
  "id" : 381171821829058560,
  "created_at" : "2013-09-20 21:43:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/381171235704414208\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/5KRCByiwxM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUoxOCdCIAA-r9B.png",
      "id_str" : "381171235712802816",
      "id" : 381171235712802816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUoxOCdCIAA-r9B.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5KRCByiwxM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381171235704414208",
  "text" : "Wow, I am fast, but my fasted time on a happy wheels game was .16 seconds http:\/\/t.co\/5KRCByiwxM",
  "id" : 381171235704414208,
  "created_at" : "2013-09-20 21:41:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/381170819612696576\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/yQT27CIY35",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUow10fCQAEi2gH.png",
      "id_str" : "381170819646242817",
      "id" : 381170819646242817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUow10fCQAEi2gH.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yQT27CIY35"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381170819612696576",
  "text" : "Happy wheels is the only place where you die on a virtual rollercoaster, at least that I know off, lol http:\/\/t.co\/yQT27CIY35",
  "id" : 381170819612696576,
  "created_at" : "2013-09-20 21:39:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/YSYfujxZQI",
      "expanded_url" : "http:\/\/www.totaljerkface.com\/profile.php?id=4750376",
      "display_url" : "totaljerkface.com\/profile.php?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381170340488937472",
  "text" : "Happy wheels profile: http:\/\/t.co\/YSYfujxZQI",
  "id" : 381170340488937472,
  "created_at" : "2013-09-20 21:37:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/381167752028749827\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/48FgkRiolw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUouDQvCAAADc3G.png",
      "id_str" : "381167752032944128",
      "id" : 381167752032944128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUouDQvCAAADc3G.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/48FgkRiolw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381167752028749827",
  "text" : "Dang it http:\/\/t.co\/48FgkRiolw",
  "id" : 381167752028749827,
  "created_at" : "2013-09-20 21:27:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/381167477188603904\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/mjIHAR0lkF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUotzQ4CMAEaFx7.png",
      "id_str" : "381167477192798209",
      "id" : 381167477192798209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUotzQ4CMAEaFx7.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mjIHAR0lkF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381167477188603904",
  "text" : "So good at happy wheels http:\/\/t.co\/mjIHAR0lkF",
  "id" : 381167477188603904,
  "created_at" : "2013-09-20 21:26:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/381167066754990080\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/C0OVVBuINR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUotbX5CQAA-cHR.png",
      "id_str" : "381167066759184384",
      "id" : 381167066759184384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUotbX5CQAA-cHR.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C0OVVBuINR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381167066754990080",
  "text" : "What the hell? http:\/\/t.co\/C0OVVBuINR",
  "id" : 381167066754990080,
  "created_at" : "2013-09-20 21:24:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/381165314668384257\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/hKdr2haliu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUor1Y3CUAAggIo.png",
      "id_str" : "381165314672578560",
      "id" : 381165314672578560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUor1Y3CUAAggIo.png",
      "sizes" : [ {
        "h" : 520,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 943
      } ],
      "display_url" : "pic.twitter.com\/hKdr2haliu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381165314668384257",
  "text" : "What just happened? http:\/\/t.co\/hKdr2haliu",
  "id" : 381165314668384257,
  "created_at" : "2013-09-20 21:17:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380527664861179904\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/Om6mS4LN97",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUfn5SOCcAA3t3t.png",
      "id_str" : "380527664865374208",
      "id" : 380527664865374208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUfn5SOCcAA3t3t.png",
      "sizes" : [ {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/Om6mS4LN97"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380527664861179904",
  "text" : "Last game of the day http:\/\/t.co\/Om6mS4LN97",
  "id" : 380527664861179904,
  "created_at" : "2013-09-19 03:03:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380525100102995968\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/ZQSsiODKmp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUflj_wCUAEOLzr.png",
      "id_str" : "380525100107190273",
      "id" : 380525100107190273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUflj_wCUAEOLzr.png",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZQSsiODKmp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380525100102995968",
  "text" : "Victory http:\/\/t.co\/ZQSsiODKmp",
  "id" : 380525100102995968,
  "created_at" : "2013-09-19 02:53:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380524534505283585\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/G07R2Wl51F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUflDEvCIAADBkU.png",
      "id_str" : "380524534509477888",
      "id" : 380524534509477888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUflDEvCIAADBkU.png",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G07R2Wl51F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380524534505283585",
  "text" : "That looks painful http:\/\/t.co\/G07R2Wl51F",
  "id" : 380524534505283585,
  "created_at" : "2013-09-19 02:51:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380523710542663680\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/IsFSR5iC40",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUfkTHPCUAAlWpk.png",
      "id_str" : "380523710546857984",
      "id" : 380523710546857984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUfkTHPCUAAlWpk.png",
      "sizes" : [ {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/IsFSR5iC40"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380523710542663680",
  "text" : "I flied http:\/\/t.co\/IsFSR5iC40",
  "id" : 380523710542663680,
  "created_at" : "2013-09-19 02:48:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380523290583773184\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/LuNg1e3zhR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUfj6qxCMAA6rSs.png",
      "id_str" : "380523290587967488",
      "id" : 380523290587967488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUfj6qxCMAA6rSs.png",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LuNg1e3zhR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380523290583773184",
  "text" : "Nailed it http:\/\/t.co\/LuNg1e3zhR",
  "id" : 380523290583773184,
  "created_at" : "2013-09-19 02:46:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380522686075527169",
  "text" : "::P happywheels",
  "id" : 380522686075527169,
  "created_at" : "2013-09-19 02:44:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380522643369103361\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/IkcBHIrlqi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUfjU_tCEAA9xlH.png",
      "id_str" : "380522643373297664",
      "id" : 380522643373297664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUfjU_tCEAA9xlH.png",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IkcBHIrlqi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380522643369103361",
  "text" : "LOL http:\/\/t.co\/IkcBHIrlqi",
  "id" : 380522643369103361,
  "created_at" : "2013-09-19 02:44:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380522587433885697\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/VO6JHsYx5h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUfjRvVCYAAOa1r.png",
      "id_str" : "380522587438080000",
      "id" : 380522587438080000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUfjRvVCYAAOa1r.png",
      "sizes" : [ {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/VO6JHsYx5h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380522587433885697",
  "text" : "Ouch http:\/\/t.co\/VO6JHsYx5h",
  "id" : 380522587433885697,
  "created_at" : "2013-09-19 02:43:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380522520199196673",
  "text" : "LOL",
  "id" : 380522520199196673,
  "created_at" : "2013-09-19 02:43:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380520819283066880",
  "text" : "Ouch",
  "id" : 380520819283066880,
  "created_at" : "2013-09-19 02:36:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380519287800070144\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/BtjjxH78jD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUfgRrPCAAAIORp.png",
      "id_str" : "380519287804264448",
      "id" : 380519287804264448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUfgRrPCAAAIORp.png",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BtjjxH78jD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380519287800070144",
  "text" : "YES!!! http:\/\/t.co\/BtjjxH78jD",
  "id" : 380519287800070144,
  "created_at" : "2013-09-19 02:30:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/380515758683332609\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/EfXB6FaSYW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUfdEQQCIAENoAs.png",
      "id_str" : "380515758687526913",
      "id" : 380515758687526913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUfdEQQCIAENoAs.png",
      "sizes" : [ {
        "h" : 541,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 735
      } ],
      "display_url" : "pic.twitter.com\/EfXB6FaSYW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380515758683332609",
  "text" : "Yeah http:\/\/t.co\/EfXB6FaSYW",
  "id" : 380515758683332609,
  "created_at" : "2013-09-19 02:16:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/wF1xR17052",
      "expanded_url" : "http:\/\/sdrv.ms\/1aMhNQ4",
      "display_url" : "sdrv.ms\/1aMhNQ4"
    } ]
  },
  "geo" : { },
  "id_str" : "380513609220374528",
  "text" : "Amazing http:\/\/t.co\/wF1xR17052",
  "id" : 380513609220374528,
  "created_at" : "2013-09-19 02:08:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380496368865116160",
  "text" : "Had another sandwich, this time with kettle chips in it, and I went to drivers ed, lol",
  "id" : 380496368865116160,
  "created_at" : "2013-09-19 00:59:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380446605662781440",
  "text" : "Hard salami and mozzarella on rye, yes",
  "id" : 380446605662781440,
  "created_at" : "2013-09-18 21:41:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380135764434358272",
  "text" : "Had crappy day at drivers ed, and corrected the teacher, lol, people are annoying in that class, including the teacher, lol",
  "id" : 380135764434358272,
  "created_at" : "2013-09-18 01:06:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379707885716242432",
  "text" : "I meant nighthawkinlight, lol :-)",
  "id" : 379707885716242432,
  "created_at" : "2013-09-16 20:46:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379707330168111104",
  "text" : "One time like 5 month ago, I talked to Nighthawkinthelight on YouTube, guess what he replies to some of his messages, epic xd",
  "id" : 379707330168111104,
  "created_at" : "2013-09-16 20:44:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379618321059938304",
  "text" : "Including the university courses, I got 24 assignments to do, plus I have driver's ed, feeling tired",
  "id" : 379618321059938304,
  "created_at" : "2013-09-16 14:50:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379435829921198082",
  "text" : "You know what, I will sleep now and work harder tomorrow, stressful load man, lol",
  "id" : 379435829921198082,
  "created_at" : "2013-09-16 02:45:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/TxcXsD4i2w",
      "expanded_url" : "http:\/\/sdrv.ms\/1glgZSF",
      "display_url" : "sdrv.ms\/1glgZSF"
    } ]
  },
  "geo" : { },
  "id_str" : "379431677480935425",
  "text" : "Homemade pizza, will eat then get to work, lol http:\/\/t.co\/TxcXsD4i2w",
  "id" : 379431677480935425,
  "created_at" : "2013-09-16 02:28:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379426741657169921",
  "text" : "Yeah I just tweeted that!!!!!!!!",
  "id" : 379426741657169921,
  "created_at" : "2013-09-16 02:09:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379426677618536450",
  "text" : "I sound desperate, lol, jk",
  "id" : 379426677618536450,
  "created_at" : "2013-09-16 02:09:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zendaya",
      "screen_name" : "Zendaya",
      "indices" : [ 0, 8 ],
      "id_str" : "154280902",
      "id" : 154280902
    }, {
      "name" : "OAKLAND RAIDERS",
      "screen_name" : "RAIDERS",
      "indices" : [ 9, 17 ],
      "id_str" : "16332223",
      "id" : 16332223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379347370225328128",
  "geo" : { },
  "id_str" : "379426388484161536",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya @RAIDERS Hey can you follow me at twitter, lol :P",
  "id" : 379426388484161536,
  "in_reply_to_status_id" : 379347370225328128,
  "created_at" : "2013-09-16 02:07:55 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zendaya",
      "screen_name" : "Zendaya",
      "indices" : [ 0, 8 ],
      "id_str" : "154280902",
      "id" : 154280902
    }, {
      "name" : "OAKLAND RAIDERS",
      "screen_name" : "RAIDERS",
      "indices" : [ 9, 17 ],
      "id_str" : "16332223",
      "id" : 16332223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379404758059986945",
  "geo" : { },
  "id_str" : "379426280573108225",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya @RAIDERS Hey can you follow me at twitter, lol",
  "id" : 379426280573108225,
  "in_reply_to_status_id" : 379404758059986945,
  "created_at" : "2013-09-16 02:07:29 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379426092580225024",
  "text" : "Just tweeted that",
  "id" : 379426092580225024,
  "created_at" : "2013-09-16 02:06:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379426021801349121",
  "text" : "Honors in everything, oh I am so tired",
  "id" : 379426021801349121,
  "created_at" : "2013-09-16 02:06:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/379422975239286785\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/kMseFwKZza",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUP7L4sCcAEXCAu.jpg",
      "id_str" : "379422975243481089",
      "id" : 379422975243481089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUP7L4sCcAEXCAu.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/kMseFwKZza"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379422975239286785",
  "text" : "LOL, look at my face, stunned mode http:\/\/t.co\/kMseFwKZza",
  "id" : 379422975239286785,
  "created_at" : "2013-09-16 01:54:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379422748268716032",
  "text" : "I have so much work to do, gonna have to pull an all-nighter, so much edx courses, then schooling, on top of that I need to do 12+p report",
  "id" : 379422748268716032,
  "created_at" : "2013-09-16 01:53:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379342089911545857",
  "text" : "Drove a Pontiac g6 with am instructor, then my sis, still better driver, lol",
  "id" : 379342089911545857,
  "created_at" : "2013-09-15 20:32:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379019573951225856",
  "text" : "My little sis is so predictable",
  "id" : 379019573951225856,
  "created_at" : "2013-09-14 23:11:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378996764294266880",
  "text" : "This day was awesome but when my mom comes home I gotta study, lol",
  "id" : 378996764294266880,
  "created_at" : "2013-09-14 21:40:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/f78MelDYcg",
      "expanded_url" : "http:\/\/sdrv.ms\/1aA4ySg",
      "display_url" : "sdrv.ms\/1aA4ySg"
    } ]
  },
  "geo" : { },
  "id_str" : "378960910976839680",
  "text" : "5\/5 http:\/\/t.co\/f78MelDYcg",
  "id" : 378960910976839680,
  "created_at" : "2013-09-14 19:18:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Lx7FWp2jnN",
      "expanded_url" : "http:\/\/sdrv.ms\/16t9ffR",
      "display_url" : "sdrv.ms\/16t9ffR"
    } ]
  },
  "geo" : { },
  "id_str" : "378959132088627200",
  "text" : "I rate the Rothenburg a 5\/5 stars, best birthday gift ever http:\/\/t.co\/Lx7FWp2jnN",
  "id" : 378959132088627200,
  "created_at" : "2013-09-14 19:11:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378874467235422208",
  "text" : "Was nerve recking, lol, but still fun",
  "id" : 378874467235422208,
  "created_at" : "2013-09-14 13:34:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378874346028408832",
  "text" : "Today rode a car for first time with instructed, it was a ford, rode in neighborhood, drove better then my sis, lol",
  "id" : 378874346028408832,
  "created_at" : "2013-09-14 13:34:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378704016374366209",
  "text" : "Australians are weird, lol",
  "id" : 378704016374366209,
  "created_at" : "2013-09-14 02:17:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378703529864478720",
  "text" : "Oh gosh lol",
  "id" : 378703529864478720,
  "created_at" : "2013-09-14 02:15:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378703490878435328",
  "text" : "LOL, and it was in manderin not even chinese, lol",
  "id" : 378703490878435328,
  "created_at" : "2013-09-14 02:15:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378702584820670464",
  "text" : "LOL THE MOVIE WAS SO CONFUSING",
  "id" : 378702584820670464,
  "created_at" : "2013-09-14 02:11:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca",
      "screen_name" : "allvoices",
      "indices" : [ 129, 139 ],
      "id_str" : "3984761614",
      "id" : 3984761614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/mwpXBbhbh2",
      "expanded_url" : "http:\/\/tinyurl.com\/mx9yfva",
      "display_url" : "tinyurl.com\/mx9yfva"
    } ]
  },
  "geo" : { },
  "id_str" : "378702329957978112",
  "text" : "AndSocialREW Publishes Research on The Ives Stilwell's Experimental Flaw, Changes the Laws of Physics http:\/\/t.co\/mwpXBbhbh2 via @allvoices",
  "id" : 378702329957978112,
  "created_at" : "2013-09-14 02:10:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378693225265246208",
  "text" : "Watched first 1hr of Tai chi Zero, got boring after, watched on Netflix for windows phone :)",
  "id" : 378693225265246208,
  "created_at" : "2013-09-14 01:34:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378539409857318912",
  "text" : "Finished 5hrs worth of work in 1hr, how do I feel? Energized",
  "id" : 378539409857318912,
  "created_at" : "2013-09-13 15:23:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/378505160235814912\/photo\/1",
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/XysrC5E3rL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUC4cBYCEAAU2Ji.jpg",
      "id_str" : "378505160244203520",
      "id" : 378505160244203520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUC4cBYCEAAU2Ji.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/XysrC5E3rL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378505160235814912",
  "text" : "LOL http:\/\/t.co\/XysrC5E3rL",
  "id" : 378505160235814912,
  "created_at" : "2013-09-13 13:07:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378504938663313409",
  "text" : "I got top comments in tons of other videos, every comment I post is really meaningful &amp; usually gets the top comment or at least likes",
  "id" : 378504938663313409,
  "created_at" : "2013-09-13 13:06:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/378504339678978048\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3wFmOTrHNW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUC3sQkCYAARWd2.png",
      "id_str" : "378504339687366656",
      "id" : 378504339687366656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUC3sQkCYAARWd2.png",
      "sizes" : [ {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3wFmOTrHNW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378504339678978048",
  "text" : "Some youtuber flagged my top comment for spam, lol, this is why I don't post these comments in those types of videos http:\/\/t.co\/3wFmOTrHNW",
  "id" : 378504339678978048,
  "created_at" : "2013-09-13 13:04:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378501193191796737",
  "text" : "Happy Yom Kippur, I hope your all written in the book of life :)",
  "id" : 378501193191796737,
  "created_at" : "2013-09-13 12:51:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.reverbnation.com\/\" rel=\"nofollow\"\u003EReverbNation\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "music",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/xHhibyHnA2",
      "expanded_url" : "http:\/\/www.reverbnation.com\/c.\/poni\/227832535",
      "display_url" : "reverbnation.com\/c.\/poni\/227832\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378362172897648641",
  "text" : "Posted a new song: \"Do You Remember (Christian Funeral Song)\" http:\/\/t.co\/xHhibyHnA2 #music",
  "id" : 378362172897648641,
  "created_at" : "2013-09-13 03:39:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378322676752068608",
  "text" : "I'm depressed, well was, anyways went to drivers ed today, lol",
  "id" : 378322676752068608,
  "created_at" : "2013-09-13 01:02:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377958066891001857",
  "text" : "Went to drivers Ed again, oh the socially awkward experiences",
  "id" : 377958066891001857,
  "created_at" : "2013-09-12 00:53:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377898402715287552",
  "text" : "Gosh my life is just so messed up right now, you have no idea do you guys?",
  "id" : 377898402715287552,
  "created_at" : "2013-09-11 20:56:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598618485923840",
  "text" : "Went to drivers ed today, two girls in front of me were annoying (kept laughing), when I told them they lashed out and lol offended, lol",
  "id" : 377598618485923840,
  "created_at" : "2013-09-11 01:05:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377223383232290817",
  "text" : "Many times I saw accidents, not one of them, lol, typical",
  "id" : 377223383232290817,
  "created_at" : "2013-09-10 00:13:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377199942449627136",
  "text" : "At driver's ED",
  "id" : 377199942449627136,
  "created_at" : "2013-09-09 22:40:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376777518550106112",
  "text" : "Also got a speedy freeze, lol",
  "id" : 376777518550106112,
  "created_at" : "2013-09-08 18:42:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376776412633788417",
  "text" : "My sis didn't want the rest of hers, lol",
  "id" : 376776412633788417,
  "created_at" : "2013-09-08 18:37:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376776351711522817",
  "text" : "Had two and a half Turkish delight and Lebanese candy pieces",
  "id" : 376776351711522817,
  "created_at" : "2013-09-08 18:37:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376751241579098113",
  "text" : "Lol on other things I didn't mention",
  "id" : 376751241579098113,
  "created_at" : "2013-09-08 16:57:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376751142635864064",
  "text" : "So nervous on some aspects",
  "id" : 376751142635864064,
  "created_at" : "2013-09-08 16:57:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376751066681200642",
  "text" : "Lol",
  "id" : 376751066681200642,
  "created_at" : "2013-09-08 16:57:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376751032664997889",
  "text" : "I am great with children",
  "id" : 376751032664997889,
  "created_at" : "2013-09-08 16:57:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376750994698162176",
  "text" : "One time I played with a three year old in my neighborhood, used to race cars",
  "id" : 376750994698162176,
  "created_at" : "2013-09-08 16:56:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376750860564713472",
  "text" : "The little cousins, or should I say nephews, lol",
  "id" : 376750860564713472,
  "created_at" : "2013-09-08 16:56:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376551036619853824",
  "text" : "It was delicious",
  "id" : 376551036619853824,
  "created_at" : "2013-09-08 03:42:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376550978163867648",
  "text" : "Made plain bagel sandwich with Greek feta, shredded chedder, chredded mozzarella, thin salami, thin buffalo style chicken breast",
  "id" : 376550978163867648,
  "created_at" : "2013-09-08 03:42:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376400494035750912",
  "text" : "Rock on those tweets, jk",
  "id" : 376400494035750912,
  "created_at" : "2013-09-07 17:44:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376400428831084545",
  "text" : "Lol, tweet me",
  "id" : 376400428831084545,
  "created_at" : "2013-09-07 17:43:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376399985149214720",
  "text" : "I am doing it now",
  "id" : 376399985149214720,
  "created_at" : "2013-09-07 17:42:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376399953968762880",
  "text" : "Who knows",
  "id" : 376399953968762880,
  "created_at" : "2013-09-07 17:41:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376399923887230976",
  "text" : "Why do I sometimes talk to myself",
  "id" : 376399923887230976,
  "created_at" : "2013-09-07 17:41:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376399850876985344",
  "text" : "What is up with that",
  "id" : 376399850876985344,
  "created_at" : "2013-09-07 17:41:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376399805343600640",
  "text" : "Lol",
  "id" : 376399805343600640,
  "created_at" : "2013-09-07 17:41:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376399769381666816",
  "text" : "Awkward memory #1, remember in 1st grade in Alabama when you kissed that Mexican girl named Ruby?",
  "id" : 376399769381666816,
  "created_at" : "2013-09-07 17:41:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375384931473817600",
  "text" : "lol",
  "id" : 375384931473817600,
  "created_at" : "2013-09-04 22:28:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375384880479498240",
  "text" : "Parents,,,shrugg :-\/",
  "id" : 375384880479498240,
  "created_at" : "2013-09-04 22:28:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374389406536585216",
  "text" : "Made homemade limeade was delicious",
  "id" : 374389406536585216,
  "created_at" : "2013-09-02 04:32:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373928514481057792",
  "text" : "LOL, fake diet",
  "id" : 373928514481057792,
  "created_at" : "2013-08-31 22:01:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]