Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/vBOEJPFA",
      "expanded_url" : "http:\/\/youtu.be\/jI2_ADfuCyc?a",
      "display_url" : "youtu.be\/jI2_ADfuCyc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "273267969805656065",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/vBOEJPFA muhammad_full_movie_-_innocence_of_muslims_74_min 3D",
  "id" : 273267969805656065,
  "created_at" : "2012-11-27 03:32:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/CHrh5NPp",
      "expanded_url" : "http:\/\/youtu.be\/n-WTzw7q5RQ?a",
      "display_url" : "youtu.be\/n-WTzw7q5RQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "272758373374648320",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/CHrh5NPp Greates Inventions of the 21st Century",
  "id" : 272758373374648320,
  "created_at" : "2012-11-25 17:47:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport_____",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "272405095000457216",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport_____",
  "id" : 272405095000457216,
  "created_at" : "2012-11-24 18:23:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "272405047428644865",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 272405047428644865,
  "created_at" : "2012-11-24 18:23:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "272404980915396609",
  "text" : "Child Prodigy and Genius Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 272404980915396609,
  "created_at" : "2012-11-24 18:23:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "272404761888817152",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on Furthest Distance Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 272404761888817152,
  "created_at" : "2012-11-24 18:22:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "indices" : [ 0, 10 ],
      "id_str" : "95023423",
      "id" : 95023423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "271311285239558145",
  "in_reply_to_user_id" : 95023423,
  "text" : "@Uberfacts Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 271311285239558145,
  "created_at" : "2012-11-21 17:57:05 +0000",
  "in_reply_to_screen_name" : "UberFacts",
  "in_reply_to_user_id_str" : "95023423",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F Syfi Malik",
      "screen_name" : "syfi",
      "indices" : [ 0, 5 ],
      "id_str" : "979070766",
      "id" : 979070766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "271310750914596864",
  "text" : "@SYFI Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 271310750914596864,
  "created_at" : "2012-11-21 17:54:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TeamSteamUSA",
      "screen_name" : "TeamSteam_USA",
      "indices" : [ 0, 14 ],
      "id_str" : "757681435",
      "id" : 757681435
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "271310227188637696",
  "in_reply_to_user_id" : 757681435,
  "text" : "@TeamSteam_USA Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 271310227188637696,
  "created_at" : "2012-11-21 17:52:53 +0000",
  "in_reply_to_screen_name" : "TeamSteam_USA",
  "in_reply_to_user_id_str" : "757681435",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270602756392370176",
  "text" : "Cool http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 270602756392370176,
  "created_at" : "2012-11-19 19:01:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270602701526663168",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport---",
  "id" : 270602701526663168,
  "created_at" : "2012-11-19 19:01:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270284548850454528",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport-",
  "id" : 270284548850454528,
  "created_at" : "2012-11-18 21:57:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 0, 7 ],
      "id_str" : "24206345",
      "id" : 24206345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270284506873876480",
  "in_reply_to_user_id" : 24206345,
  "text" : "@Quirky Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 270284506873876480,
  "created_at" : "2012-11-18 21:57:02 +0000",
  "in_reply_to_screen_name" : "Quirky",
  "in_reply_to_user_id_str" : "24206345",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Space",
      "screen_name" : "space",
      "indices" : [ 0, 6 ],
      "id_str" : "1268821",
      "id" : 1268821
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270284385595572224",
  "in_reply_to_user_id" : 1268821,
  "text" : "@space.com Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 270284385595572224,
  "created_at" : "2012-11-18 21:56:33 +0000",
  "in_reply_to_screen_name" : "space",
  "in_reply_to_user_id_str" : "1268821",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270284247858835456",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport..",
  "id" : 270284247858835456,
  "created_at" : "2012-11-18 21:56:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270284194545029120",
  "in_reply_to_user_id" : 863731963,
  "text" : "@Colemanarmy Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 270284194545029120,
  "created_at" : "2012-11-18 21:55:48 +0000",
  "in_reply_to_screen_name" : "ColemanArmy",
  "in_reply_to_user_id_str" : "863731963",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Steam USA",
      "screen_name" : "TeamSteamUSA",
      "indices" : [ 0, 13 ],
      "id_str" : "339387638",
      "id" : 339387638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270284061422006273",
  "in_reply_to_user_id" : 339387638,
  "text" : "@TeamSteamUSA Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 270284061422006273,
  "created_at" : "2012-11-18 21:55:16 +0000",
  "in_reply_to_screen_name" : "TeamSteamUSA",
  "in_reply_to_user_id_str" : "339387638",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270283970808250368",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport.",
  "id" : 270283970808250368,
  "created_at" : "2012-11-18 21:54:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/s5Iyf0sf",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-881130",
      "display_url" : "ireport.cnn.com\/docs\/DOC-881130"
    } ]
  },
  "geo" : { },
  "id_str" : "270283824460611585",
  "text" : "Andrew Magdy Kamal Joins Astrophysicist Thomas Scott Zolotor on FHB Galaxies http:\/\/t.co\/s5Iyf0sf #ireport",
  "id" : 270283824460611585,
  "created_at" : "2012-11-18 21:54:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earth Pet",
      "screen_name" : "EarthPet",
      "indices" : [ 0, 9 ],
      "id_str" : "174925178",
      "id" : 174925178
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 45, 53 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/plkPjkGW",
      "expanded_url" : "http:\/\/youtu.be\/PO68etOL2rQ?a",
      "display_url" : "youtu.be\/PO68etOL2rQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "269573584618401793",
  "in_reply_to_user_id" : 174925178,
  "text" : "@earthpet you want to verify my IQ yourself (@YouTube http:\/\/t.co\/plkPjkGW)",
  "id" : 269573584618401793,
  "created_at" : "2012-11-16 22:52:05 +0000",
  "in_reply_to_screen_name" : "EarthPet",
  "in_reply_to_user_id_str" : "174925178",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earth Pet",
      "screen_name" : "EarthPet",
      "indices" : [ 0, 9 ],
      "id_str" : "174925178",
      "id" : 174925178
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/plkPjkGW",
      "expanded_url" : "http:\/\/youtu.be\/PO68etOL2rQ?a",
      "display_url" : "youtu.be\/PO68etOL2rQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "269533814466936832",
  "in_reply_to_user_id" : 174925178,
  "text" : "@earthpet see my mesage. Also I admit no such thing. Solomon and Moses had an IQ based on (@YouTube http:\/\/t.co\/plkPjkGW)",
  "id" : 269533814466936832,
  "created_at" : "2012-11-16 20:14:03 +0000",
  "in_reply_to_screen_name" : "EarthPet",
  "in_reply_to_user_id_str" : "174925178",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/plkPjkGW",
      "expanded_url" : "http:\/\/youtu.be\/PO68etOL2rQ?a",
      "display_url" : "youtu.be\/PO68etOL2rQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "269491942382002176",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/plkPjkGW World's Highest IQs",
  "id" : 269491942382002176,
  "created_at" : "2012-11-16 17:27:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/plkPjkGW",
      "expanded_url" : "http:\/\/youtu.be\/PO68etOL2rQ?a",
      "display_url" : "youtu.be\/PO68etOL2rQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "269491887751172098",
  "text" : "This information is historically accurate,also I am a member of the Glia society, but I use (@YouTube http:\/\/t.co\/plkPjkGW)",
  "id" : 269491887751172098,
  "created_at" : "2012-11-16 17:27:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/plkPjkGW",
      "expanded_url" : "http:\/\/youtu.be\/PO68etOL2rQ?a",
      "display_url" : "youtu.be\/PO68etOL2rQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "269449272368443392",
  "text" : "What are you talking about????????????? (@YouTube http:\/\/t.co\/plkPjkGW)",
  "id" : 269449272368443392,
  "created_at" : "2012-11-16 14:38:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/Yyi3u2bb",
      "expanded_url" : "http:\/\/youtu.be\/bQ6Do50Eel0?a",
      "display_url" : "youtu.be\/bQ6Do50Eel0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "268228563008884736",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/Yyi3u2bb The full-length lesbian kiss scene from Friends",
  "id" : 268228563008884736,
  "created_at" : "2012-11-13 05:47:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/XQJHXCww",
      "expanded_url" : "http:\/\/youtu.be\/lXJFHtmS2LU?a",
      "display_url" : "youtu.be\/lXJFHtmS2LU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "268126634803077120",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/XQJHXCww FHB Galaxies (As Seen on the Discovery Channel)",
  "id" : 268126634803077120,
  "created_at" : "2012-11-12 23:02:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/9SC6tRd4",
      "expanded_url" : "http:\/\/youtu.be\/qrTFSmEjE8o?a",
      "display_url" : "youtu.be\/qrTFSmEjE8o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266554898525585409",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/9SC6tRd4 Nibiru Spotted Twice",
  "id" : 266554898525585409,
  "created_at" : "2012-11-08 14:56:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/9SC6tRd4",
      "expanded_url" : "http:\/\/youtu.be\/qrTFSmEjE8o?a",
      "display_url" : "youtu.be\/qrTFSmEjE8o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266300400683077632",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/9SC6tRd4 Nibiru Spotted Twice",
  "id" : 266300400683077632,
  "created_at" : "2012-11-07 22:05:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/lTkdEHR3",
      "expanded_url" : "http:\/\/youtu.be\/ymHbWl0AVHY?a",
      "display_url" : "youtu.be\/ymHbWl0AVHY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266284202872422400",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/lTkdEHR3 My Interview Based On the Two Greatest Greek Philosophers",
  "id" : 266284202872422400,
  "created_at" : "2012-11-07 21:01:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/wgXznfj3",
      "expanded_url" : "http:\/\/youtu.be\/6tCOtTufuLA?a",
      "display_url" : "youtu.be\/6tCOtTufuLA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266210829018464257",
  "text" : "I am coptic (@YouTube http:\/\/t.co\/wgXznfj3)",
  "id" : 266210829018464257,
  "created_at" : "2012-11-07 16:09:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 45, 53 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/wgXznfj3",
      "expanded_url" : "http:\/\/youtu.be\/6tCOtTufuLA?a",
      "display_url" : "youtu.be\/6tCOtTufuLA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266210655995043841",
  "text" : "I am not islam, this is an anti-islam video (@YouTube http:\/\/t.co\/wgXznfj3)",
  "id" : 266210655995043841,
  "created_at" : "2012-11-07 16:09:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 31, 39 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/wgXznfj3",
      "expanded_url" : "http:\/\/youtu.be\/6tCOtTufuLA?a",
      "display_url" : "youtu.be\/6tCOtTufuLA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266209810876354560",
  "text" : "God bless you and your family (@YouTube http:\/\/t.co\/wgXznfj3)",
  "id" : 266209810876354560,
  "created_at" : "2012-11-07 16:05:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/plkPjkGW",
      "expanded_url" : "http:\/\/youtu.be\/PO68etOL2rQ?a",
      "display_url" : "youtu.be\/PO68etOL2rQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266209581569560576",
  "text" : "Logically impossible to get that high of an IQ, and you wouldn't be talking that way if your (@YouTube http:\/\/t.co\/plkPjkGW)",
  "id" : 266209581569560576,
  "created_at" : "2012-11-07 16:04:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/moOQMaF1",
      "expanded_url" : "http:\/\/youtu.be\/OGfVsHG1Tow?a",
      "display_url" : "youtu.be\/OGfVsHG1Tow?a"
    } ]
  },
  "geo" : { },
  "id_str" : "266190651740258304",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/moOQMaF1 Yirat Adonai",
  "id" : 266190651740258304,
  "created_at" : "2012-11-07 14:49:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/F6aFF1yd",
      "expanded_url" : "http:\/\/youtu.be\/9DsMjBEFs3o?a",
      "display_url" : "youtu.be\/9DsMjBEFs3o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "265644111737008129",
  "text" : "God bless you, and God forgive you, those who seek forgiveness are entered into the kingdom of (@YouTube http:\/\/t.co\/F6aFF1yd)",
  "id" : 265644111737008129,
  "created_at" : "2012-11-06 02:37:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 22, 30 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/XGcHvzg4",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "265588807770976256",
  "text" : "@EvoPitz Really Even (@YouTube http:\/\/t.co\/XGcHvzg4)",
  "id" : 265588807770976256,
  "created_at" : "2012-11-05 22:58:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/plkPjkGW",
      "expanded_url" : "http:\/\/youtu.be\/PO68etOL2rQ?a",
      "display_url" : "youtu.be\/PO68etOL2rQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "265491649810014210",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/plkPjkGW World's Highest IQs",
  "id" : 265491649810014210,
  "created_at" : "2012-11-05 16:31:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/wgXznfj3",
      "expanded_url" : "http:\/\/youtu.be\/6tCOtTufuLA?a",
      "display_url" : "youtu.be\/6tCOtTufuLA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "264412953762209792",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/wgXznfj3 Muslims Killing CHRISTIANS, REMEMBER THE MARTYRS",
  "id" : 264412953762209792,
  "created_at" : "2012-11-02 17:05:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/F6aFF1yd",
      "expanded_url" : "http:\/\/youtu.be\/9DsMjBEFs3o?a",
      "display_url" : "youtu.be\/9DsMjBEFs3o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "264198324503060480",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/F6aFF1yd Elshadi",
  "id" : 264198324503060480,
  "created_at" : "2012-11-02 02:52:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/vYRe1EGf",
      "expanded_url" : "http:\/\/youtu.be\/LOvnE1cP3_s?a",
      "display_url" : "youtu.be\/LOvnE1cP3_s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "264194930862342144",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/vYRe1EGf Would You Want This Person in a Fight",
  "id" : 264194930862342144,
  "created_at" : "2012-11-02 02:39:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ZkjJF5jH",
      "expanded_url" : "http:\/\/youtu.be\/4nh59fZr_Ys?a",
      "display_url" : "youtu.be\/4nh59fZr_Ys?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263788527848927232",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ZkjJF5jH HNI 0022",
  "id" : 263788527848927232,
  "created_at" : "2012-10-31 23:44:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/k7Ql2ukY",
      "expanded_url" : "http:\/\/youtu.be\/Y2l32rrgOmo?a",
      "display_url" : "youtu.be\/Y2l32rrgOmo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263788529056890880",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/k7Ql2ukY Coolness of Lasers 1",
  "id" : 263788529056890880,
  "created_at" : "2012-10-31 23:44:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/n9cfcb0c",
      "expanded_url" : "http:\/\/youtu.be\/e5Ue7wH3XzM?a",
      "display_url" : "youtu.be\/e5Ue7wH3XzM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263778419257516032",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/n9cfcb0c Teen Version of the Next Rocky",
  "id" : 263778419257516032,
  "created_at" : "2012-10-31 23:04:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]