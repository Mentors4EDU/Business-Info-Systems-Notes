Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oddinventions",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527856050498572288",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze I am not entering the #oddinventions challenge this year, my inventions are too normal :(",
  "id" : 527856050498572288,
  "created_at" : "2014-10-30 16:14:24 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527855903274328064",
  "text" : "RT @colin_furze: New video out Thursday. Sorry it's been a while but things take time to make etc yeah yeah Colin your just slow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526701249505558528",
    "text" : "New video out Thursday. Sorry it's been a while but things take time to make etc yeah yeah Colin your just slow.",
    "id" : 526701249505558528,
    "created_at" : "2014-10-27 11:45:38 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 527855903274328064,
  "created_at" : "2014-10-30 16:13:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3D Agent",
      "screen_name" : "3D_Agent",
      "indices" : [ 3, 12 ],
      "id_str" : "2249138370",
      "id" : 2249138370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3D",
      "indices" : [ 118, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/D05EPvknt8",
      "expanded_url" : "http:\/\/ift.tt\/10B7Tkw",
      "display_url" : "ift.tt\/10B7Tkw"
    } ]
  },
  "geo" : { },
  "id_str" : "527854507217022976",
  "text" : "RT @3D_Agent: MakerBot Announces Latest Updates: Welcome to MakerBot Desktop 3.3, Firmware 1.4 http:\/\/t.co\/D05EPvknt8 #3D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "3D",
        "indices" : [ 104, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/D05EPvknt8",
        "expanded_url" : "http:\/\/ift.tt\/10B7Tkw",
        "display_url" : "ift.tt\/10B7Tkw"
      } ]
    },
    "geo" : { },
    "id_str" : "527794388425273344",
    "text" : "MakerBot Announces Latest Updates: Welcome to MakerBot Desktop 3.3, Firmware 1.4 http:\/\/t.co\/D05EPvknt8 #3D",
    "id" : 527794388425273344,
    "created_at" : "2014-10-30 12:09:22 +0000",
    "user" : {
      "name" : "3D Agent",
      "screen_name" : "3D_Agent",
      "protected" : false,
      "id_str" : "2249138370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412652576954261504\/xanRudlW_normal.jpeg",
      "id" : 2249138370,
      "verified" : false
    }
  },
  "id" : 527854507217022976,
  "created_at" : "2014-10-30 16:08:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/527854165804859392\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/9lOsiWfnaq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1NQkDuCMAAYo2S.jpg",
      "id_str" : "527854161736380416",
      "id" : 527854161736380416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1NQkDuCMAAYo2S.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1222,
        "resize" : "fit",
        "w" : 1630
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9lOsiWfnaq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527854165804859392",
  "text" : "Do you know the muffin man? If not, may I make an introduction? :) http:\/\/t.co\/9lOsiWfnaq",
  "id" : 527854165804859392,
  "created_at" : "2014-10-30 16:06:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DarthReptile\uD83C\uDF10",
      "screen_name" : "MrRepzion",
      "indices" : [ 0, 10 ],
      "id_str" : "346062069",
      "id" : 346062069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526835962416873472",
  "in_reply_to_user_id" : 346062069,
  "text" : "@MrRepzion I know thousands of people probably asked you this, but I got to know, do you code? :) If so what's your favorite language?",
  "id" : 526835962416873472,
  "created_at" : "2014-10-27 20:40:56 +0000",
  "in_reply_to_screen_name" : "MrRepzion",
  "in_reply_to_user_id_str" : "346062069",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3D Agent",
      "screen_name" : "3D_Agent",
      "indices" : [ 3, 12 ],
      "id_str" : "2249138370",
      "id" : 2249138370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3D",
      "indices" : [ 83, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/CGiTNaETMH",
      "expanded_url" : "http:\/\/ift.tt\/ZRGQQp",
      "display_url" : "ift.tt\/ZRGQQp"
    } ]
  },
  "geo" : { },
  "id_str" : "526500182087569408",
  "text" : "RT @3D_Agent: Make a Destiny Gun Replica Using a 3d Printer http:\/\/t.co\/CGiTNaETMH #3D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "3D",
        "indices" : [ 69, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/CGiTNaETMH",
        "expanded_url" : "http:\/\/ift.tt\/ZRGQQp",
        "display_url" : "ift.tt\/ZRGQQp"
      } ]
    },
    "geo" : { },
    "id_str" : "526496124191145985",
    "text" : "Make a Destiny Gun Replica Using a 3d Printer http:\/\/t.co\/CGiTNaETMH #3D",
    "id" : 526496124191145985,
    "created_at" : "2014-10-26 22:10:32 +0000",
    "user" : {
      "name" : "3D Agent",
      "screen_name" : "3D_Agent",
      "protected" : false,
      "id_str" : "2249138370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412652576954261504\/xanRudlW_normal.jpeg",
      "id" : 2249138370,
      "verified" : false
    }
  },
  "id" : 526500182087569408,
  "created_at" : "2014-10-26 22:26:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526499591206617088",
  "text" : "Aged peppers and olives taste great :)",
  "id" : 526499591206617088,
  "created_at" : "2014-10-26 22:24:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/VukF2LIYiV",
      "expanded_url" : "http:\/\/1drv.ms\/1pO7Qrb",
      "display_url" : "1drv.ms\/1pO7Qrb"
    } ]
  },
  "geo" : { },
  "id_str" : "526452316589678593",
  "text" : "My parents took the family out for an ice cream treat :) http:\/\/t.co\/VukF2LIYiV",
  "id" : 526452316589678593,
  "created_at" : "2014-10-26 19:16:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/dK6jvJbRoo",
      "expanded_url" : "http:\/\/1drv.ms\/1oLx0vy",
      "display_url" : "1drv.ms\/1oLx0vy"
    } ]
  },
  "geo" : { },
  "id_str" : "526435094966194176",
  "text" : "My second mansion to live in because my parents are hard workers. Hopefully one day I will learn their integrity http:\/\/t.co\/dK6jvJbRoo",
  "id" : 526435094966194176,
  "created_at" : "2014-10-26 18:08:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Ben Carson",
      "screen_name" : "RealBenCarson",
      "indices" : [ 3, 17 ],
      "id_str" : "1180379185",
      "id" : 1180379185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/b9Oi8iAAob",
      "expanded_url" : "http:\/\/wp.me\/p4jJZS-90",
      "display_url" : "wp.me\/p4jJZS-90"
    } ]
  },
  "geo" : { },
  "id_str" : "526178738795335681",
  "text" : "RT @RealBenCarson: READ: Houston\u2019s First Amendment Abuse http:\/\/t.co\/b9Oi8iAAob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/b9Oi8iAAob",
        "expanded_url" : "http:\/\/wp.me\/p4jJZS-90",
        "display_url" : "wp.me\/p4jJZS-90"
      } ]
    },
    "geo" : { },
    "id_str" : "525643433176604672",
    "text" : "READ: Houston\u2019s First Amendment Abuse http:\/\/t.co\/b9Oi8iAAob",
    "id" : 525643433176604672,
    "created_at" : "2014-10-24 13:42:15 +0000",
    "user" : {
      "name" : "Dr. Ben Carson",
      "screen_name" : "RealBenCarson",
      "protected" : false,
      "id_str" : "1180379185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748168158914060288\/ppXi7Xt-_normal.jpg",
      "id" : 1180379185,
      "verified" : true
    }
  },
  "id" : 526178738795335681,
  "created_at" : "2014-10-26 01:09:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 0, 13 ],
      "id_str" : "342887079",
      "id" : 342887079
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/526178447341539329\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/OPibKix7cy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B01cgiACUAAzNW1.jpg",
      "id_str" : "526178445424742400",
      "id" : 526178445424742400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B01cgiACUAAzNW1.jpg",
      "sizes" : [ {
        "h" : 541,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 412
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 412
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 412
      } ],
      "display_url" : "pic.twitter.com\/OPibKix7cy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526178447341539329",
  "in_reply_to_user_id" : 342887079,
  "text" : "@rushlimbaugh Are you proud of me :) http:\/\/t.co\/OPibKix7cy",
  "id" : 526178447341539329,
  "created_at" : "2014-10-26 01:08:12 +0000",
  "in_reply_to_screen_name" : "rushlimbaugh",
  "in_reply_to_user_id_str" : "342887079",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "indices" : [ 0, 13 ],
      "id_str" : "43532936",
      "id" : 43532936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525248267945119745",
  "geo" : { },
  "id_str" : "525456974872195072",
  "in_reply_to_user_id" : 43532936,
  "text" : "@cohasset_kid thanks for the suggestion, Mr.Hewitt is a genius when it comes to analyzing media bias.",
  "id" : 525456974872195072,
  "in_reply_to_status_id" : 525248267945119745,
  "created_at" : "2014-10-24 01:21:19 +0000",
  "in_reply_to_screen_name" : "cohasset_kid",
  "in_reply_to_user_id_str" : "43532936",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525247250633457664",
  "text" : "I love the conservative movements going on",
  "id" : 525247250633457664,
  "created_at" : "2014-10-23 11:27:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Ben Carson",
      "screen_name" : "RealBenCarson",
      "indices" : [ 3, 17 ],
      "id_str" : "1180379185",
      "id" : 1180379185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SignPledge",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/IoUFgTUc30",
      "expanded_url" : "http:\/\/YourVoiceHeard.org",
      "display_url" : "YourVoiceHeard.org"
    } ]
  },
  "geo" : { },
  "id_str" : "525247100187996160",
  "text" : "RT @RealBenCarson: Let Freedom Ring this Nov 4th when you can cast your ballot as an informed voter #SignPledge @ http:\/\/t.co\/IoUFgTUc30 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RealBenCarson\/status\/524968592668758018\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/JKRakFthC6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0jrLT6IIAAjW1L.png",
        "id_str" : "524927936143826944",
        "id" : 524927936143826944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0jrLT6IIAAjW1L.png",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JKRakFthC6"
      } ],
      "hashtags" : [ {
        "text" : "SignPledge",
        "indices" : [ 81, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/IoUFgTUc30",
        "expanded_url" : "http:\/\/YourVoiceHeard.org",
        "display_url" : "YourVoiceHeard.org"
      } ]
    },
    "geo" : { },
    "id_str" : "524968592668758018",
    "text" : "Let Freedom Ring this Nov 4th when you can cast your ballot as an informed voter #SignPledge @ http:\/\/t.co\/IoUFgTUc30 http:\/\/t.co\/JKRakFthC6",
    "id" : 524968592668758018,
    "created_at" : "2014-10-22 17:00:40 +0000",
    "user" : {
      "name" : "Dr. Ben Carson",
      "screen_name" : "RealBenCarson",
      "protected" : false,
      "id_str" : "1180379185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748168158914060288\/ppXi7Xt-_normal.jpg",
      "id" : 1180379185,
      "verified" : true
    }
  },
  "id" : 525247100187996160,
  "created_at" : "2014-10-23 11:27:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Paul",
      "screen_name" : "RonPaul",
      "indices" : [ 3, 11 ],
      "id_str" : "287413569",
      "id" : 287413569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/JuN2nm5NSw",
      "expanded_url" : "http:\/\/bit.ly\/1uHmm5z",
      "display_url" : "bit.ly\/1uHmm5z"
    } ]
  },
  "geo" : { },
  "id_str" : "525246912207650816",
  "text" : "RT @RonPaul: Voices of Liberty looks at eight absurd government projects funded with your money. http:\/\/t.co\/JuN2nm5NSw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/JuN2nm5NSw",
        "expanded_url" : "http:\/\/bit.ly\/1uHmm5z",
        "display_url" : "bit.ly\/1uHmm5z"
      } ]
    },
    "geo" : { },
    "id_str" : "525082261289312257",
    "text" : "Voices of Liberty looks at eight absurd government projects funded with your money. http:\/\/t.co\/JuN2nm5NSw",
    "id" : 525082261289312257,
    "created_at" : "2014-10-23 00:32:21 +0000",
    "user" : {
      "name" : "Ron Paul",
      "screen_name" : "RonPaul",
      "protected" : false,
      "id_str" : "287413569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573517737172934659\/bB-v1E-8_normal.jpeg",
      "id" : 287413569,
      "verified" : true
    }
  },
  "id" : 525246912207650816,
  "created_at" : "2014-10-23 11:26:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/B0yzCihVZp",
      "expanded_url" : "http:\/\/youtu.be\/55HNU1Dq9PM?a",
      "display_url" : "youtu.be\/55HNU1Dq9PM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "525246784734388224",
  "text" : "RT @VigilantChrist: HALLOWEEN A SATANIC ILLUMINATI PAGAN RITUAL HOLIDAY EXPOSED !!! http:\/\/t.co\/B0yzCihVZp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/B0yzCihVZp",
        "expanded_url" : "http:\/\/youtu.be\/55HNU1Dq9PM?a",
        "display_url" : "youtu.be\/55HNU1Dq9PM?a"
      } ]
    },
    "geo" : { },
    "id_str" : "524715682278039552",
    "text" : "HALLOWEEN A SATANIC ILLUMINATI PAGAN RITUAL HOLIDAY EXPOSED !!! http:\/\/t.co\/B0yzCihVZp",
    "id" : 524715682278039552,
    "created_at" : "2014-10-22 00:15:42 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 525246784734388224,
  "created_at" : "2014-10-23 11:26:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/aSXCgPOZo7",
      "expanded_url" : "http:\/\/youtu.be\/BdE86GT6NxY",
      "display_url" : "youtu.be\/BdE86GT6NxY"
    } ]
  },
  "geo" : { },
  "id_str" : "525246507050479616",
  "text" : "RT @MarkDice: Toys R Us Selling Meth-Dealing Dolls To Children!!!    http:\/\/t.co\/aSXCgPOZo7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/aSXCgPOZo7",
        "expanded_url" : "http:\/\/youtu.be\/BdE86GT6NxY",
        "display_url" : "youtu.be\/BdE86GT6NxY"
      } ]
    },
    "geo" : { },
    "id_str" : "524364580836102145",
    "text" : "Toys R Us Selling Meth-Dealing Dolls To Children!!!    http:\/\/t.co\/aSXCgPOZo7",
    "id" : 524364580836102145,
    "created_at" : "2014-10-21 01:00:32 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 525246507050479616,
  "created_at" : "2014-10-23 11:25:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sesamestreet",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/UziJE7woJP",
      "expanded_url" : "http:\/\/1drv.ms\/1tjOXBl",
      "display_url" : "1drv.ms\/1tjOXBl"
    } ]
  },
  "geo" : { },
  "id_str" : "525245714423480320",
  "text" : "Cookie monsta #Sesamestreet had it yesterday!!! http:\/\/t.co\/UziJE7woJP",
  "id" : 525245714423480320,
  "created_at" : "2014-10-23 11:21:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524636992173121536",
  "text" : "Drove on the freeway, and it was fun!!!",
  "id" : 524636992173121536,
  "created_at" : "2014-10-21 19:03:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Fo2Lshgt47",
      "expanded_url" : "http:\/\/1drv.ms\/1t6Ar0S",
      "display_url" : "1drv.ms\/1t6Ar0S"
    } ]
  },
  "geo" : { },
  "id_str" : "524368063785734145",
  "text" : "One of my favorite pizza places, guess what it is? http:\/\/t.co\/Fo2Lshgt47",
  "id" : 524368063785734145,
  "created_at" : "2014-10-21 01:14:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/w4pIlGyAFX",
      "expanded_url" : "http:\/\/youtu.be\/O37GiScA01Q?a",
      "display_url" : "youtu.be\/O37GiScA01Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "523991464112427008",
  "text" : "RT @VigilantChrist: God Calls us to Rise Up and Stand Against The Illuminati Evildoers aka Workers of Iniquity !!! http:\/\/t.co\/w4pIlGyAFX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/w4pIlGyAFX",
        "expanded_url" : "http:\/\/youtu.be\/O37GiScA01Q?a",
        "display_url" : "youtu.be\/O37GiScA01Q?a"
      } ]
    },
    "geo" : { },
    "id_str" : "523184548905902080",
    "text" : "God Calls us to Rise Up and Stand Against The Illuminati Evildoers aka Workers of Iniquity !!! http:\/\/t.co\/w4pIlGyAFX",
    "id" : 523184548905902080,
    "created_at" : "2014-10-17 18:51:31 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 523991464112427008,
  "created_at" : "2014-10-20 00:17:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/baPUZcB94I",
      "expanded_url" : "http:\/\/1drv.ms\/1sZdQCl",
      "display_url" : "1drv.ms\/1sZdQCl"
    } ]
  },
  "geo" : { },
  "id_str" : "523595623207931906",
  "text" : "Had this plus the lamb chilli at Palm's Palace 4\/5 stars http:\/\/t.co\/baPUZcB94I",
  "id" : 523595623207931906,
  "created_at" : "2014-10-18 22:04:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/L50CtwpGuY",
      "expanded_url" : "http:\/\/1drv.ms\/1sRZEux",
      "display_url" : "1drv.ms\/1sRZEux"
    } ]
  },
  "geo" : { },
  "id_str" : "523241980692676608",
  "text" : "Mall Chinese :( http:\/\/t.co\/L50CtwpGuY",
  "id" : 523241980692676608,
  "created_at" : "2014-10-17 22:39:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 3, 9 ],
      "id_str" : "70266297",
      "id" : 70266297
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 38, 50 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/TkTs63F0Eq",
      "expanded_url" : "https:\/\/www.udemy.com\/the-it-survival-guide",
      "display_url" : "udemy.com\/the-it-surviva\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523212244750856192",
  "text" : "RT @udemy: 'The IT Survival Guide' by @gamer456148 now on Udemy! https:\/\/t.co\/TkTs63F0Eq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 27, 39 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/TkTs63F0Eq",
        "expanded_url" : "https:\/\/www.udemy.com\/the-it-survival-guide",
        "display_url" : "udemy.com\/the-it-surviva\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "523210643097522177",
    "text" : "'The IT Survival Guide' by @gamer456148 now on Udemy! https:\/\/t.co\/TkTs63F0Eq",
    "id" : 523210643097522177,
    "created_at" : "2014-10-17 20:35:12 +0000",
    "user" : {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "protected" : false,
      "id_str" : "70266297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787081764455915521\/k3GRWz_C_normal.jpg",
      "id" : 70266297,
      "verified" : true
    }
  },
  "id" : 523212244750856192,
  "created_at" : "2014-10-17 20:41:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/516200809231425536\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/cTmqj5fmxh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bynp5qACYAAPuzF.jpg",
      "id_str" : "516200809046892544",
      "id" : 516200809046892544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bynp5qACYAAPuzF.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/cTmqj5fmxh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521032756881412097",
  "text" : "RT @colin_furze: Colinfurze youtube videos are going international. Canada here we come (but with what???) http:\/\/t.co\/cTmqj5fmxh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/516200809231425536\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/cTmqj5fmxh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bynp5qACYAAPuzF.jpg",
        "id_str" : "516200809046892544",
        "id" : 516200809046892544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bynp5qACYAAPuzF.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com\/cTmqj5fmxh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516200809231425536",
    "text" : "Colinfurze youtube videos are going international. Canada here we come (but with what???) http:\/\/t.co\/cTmqj5fmxh",
    "id" : 516200809231425536,
    "created_at" : "2014-09-28 12:20:38 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 521032756881412097,
  "created_at" : "2014-10-11 20:21:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy John's",
      "screen_name" : "jimmyjohns",
      "indices" : [ 11, 22 ],
      "id_str" : "21952592",
      "id" : 21952592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521032444577738752",
  "text" : "Just had a @jimmyjohns turkey sub, tasted nice",
  "id" : 521032444577738752,
  "created_at" : "2014-10-11 20:19:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/torjCZRkZM",
      "expanded_url" : "http:\/\/youtu.be\/ZPl6-8PTiQw",
      "display_url" : "youtu.be\/ZPl6-8PTiQw"
    } ]
  },
  "geo" : { },
  "id_str" : "520683187517669376",
  "text" : "RT @MarkDice: Middle School Warns Teachers Words \"Boys\" &amp; \"Girls\" are Sexist - Must Use \"Gender Neutral Terms\"  http:\/\/t.co\/torjCZRkZM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/torjCZRkZM",
        "expanded_url" : "http:\/\/youtu.be\/ZPl6-8PTiQw",
        "display_url" : "youtu.be\/ZPl6-8PTiQw"
      } ]
    },
    "geo" : { },
    "id_str" : "520266729482883072",
    "text" : "Middle School Warns Teachers Words \"Boys\" &amp; \"Girls\" are Sexist - Must Use \"Gender Neutral Terms\"  http:\/\/t.co\/torjCZRkZM",
    "id" : 520266729482883072,
    "created_at" : "2014-10-09 17:37:09 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 520683187517669376,
  "created_at" : "2014-10-10 21:12:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/mQ1LKVmHc5",
      "expanded_url" : "http:\/\/1drv.ms\/1tLFnDj",
      "display_url" : "1drv.ms\/1tLFnDj"
    } ]
  },
  "geo" : { },
  "id_str" : "520682970990931968",
  "text" : "4\/5 Thai Cuisine http:\/\/t.co\/mQ1LKVmHc5",
  "id" : 520682970990931968,
  "created_at" : "2014-10-10 21:11:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adobe",
      "screen_name" : "Adobe",
      "indices" : [ 0, 6 ],
      "id_str" : "63786611",
      "id" : 63786611
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/520411989328138240\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/BWs5GLAX1t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzjf8hACUAAbizg.jpg",
      "id_str" : "520411987704958976",
      "id" : 520411987704958976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzjf8hACUAAbizg.jpg",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 651
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 651
      } ],
      "display_url" : "pic.twitter.com\/BWs5GLAX1t"
    } ],
    "hashtags" : [ {
      "text" : "sad",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520411989328138240",
  "in_reply_to_user_id" : 63786611,
  "text" : "@Adobe This just made my day #sad http:\/\/t.co\/BWs5GLAX1t",
  "id" : 520411989328138240,
  "created_at" : "2014-10-10 03:14:21 +0000",
  "in_reply_to_screen_name" : "Adobe",
  "in_reply_to_user_id_str" : "63786611",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/DpE3PQ557O",
      "expanded_url" : "http:\/\/youtu.be\/035D2ZKZ7ZE",
      "display_url" : "youtu.be\/035D2ZKZ7ZE"
    } ]
  },
  "geo" : { },
  "id_str" : "520071631356428288",
  "text" : "RT @MarkDice: New Jersey Man Arrested for Shooting Down Drone!   http:\/\/t.co\/DpE3PQ557O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/DpE3PQ557O",
        "expanded_url" : "http:\/\/youtu.be\/035D2ZKZ7ZE",
        "display_url" : "youtu.be\/035D2ZKZ7ZE"
      } ]
    },
    "geo" : { },
    "id_str" : "519190162132447232",
    "text" : "New Jersey Man Arrested for Shooting Down Drone!   http:\/\/t.co\/DpE3PQ557O",
    "id" : 519190162132447232,
    "created_at" : "2014-10-06 18:19:15 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 520071631356428288,
  "created_at" : "2014-10-09 04:41:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/2U4YwCkwzf",
      "expanded_url" : "http:\/\/1drv.ms\/1vOhHlp",
      "display_url" : "1drv.ms\/1vOhHlp"
    } ]
  },
  "geo" : { },
  "id_str" : "520071149560922112",
  "text" : "Had this yesterday plus some chocolate ;) http:\/\/t.co\/2U4YwCkwzf",
  "id" : 520071149560922112,
  "created_at" : "2014-10-09 04:39:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/T8q9mPSn4k",
      "expanded_url" : "http:\/\/youtu.be\/Db_vRk9vFn4?a",
      "display_url" : "youtu.be\/Db_vRk9vFn4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "519678650438807552",
  "text" : "RT @VigilantChrist: How I Would Take Over The World (If I Where The Devil!)  http:\/\/t.co\/T8q9mPSn4k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/T8q9mPSn4k",
        "expanded_url" : "http:\/\/youtu.be\/Db_vRk9vFn4?a",
        "display_url" : "youtu.be\/Db_vRk9vFn4?a"
      } ]
    },
    "geo" : { },
    "id_str" : "518773521346875392",
    "text" : "How I Would Take Over The World (If I Where The Devil!)  http:\/\/t.co\/T8q9mPSn4k",
    "id" : 518773521346875392,
    "created_at" : "2014-10-05 14:43:40 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 519678650438807552,
  "created_at" : "2014-10-08 02:40:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/jI9d8blwzX",
      "expanded_url" : "http:\/\/1drv.ms\/1y43bJJ",
      "display_url" : "1drv.ms\/1y43bJJ"
    } ]
  },
  "geo" : { },
  "id_str" : "519677128061644804",
  "text" : "Had Sushi, a roll, strawberry lemonade poweraide and pineapple sherbet, in my so called \"diet\" today http:\/\/t.co\/jI9d8blwzX",
  "id" : 519677128061644804,
  "created_at" : "2014-10-08 02:34:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/OITxOa2tRs",
      "expanded_url" : "http:\/\/youtu.be\/65YOuIF-HiM",
      "display_url" : "youtu.be\/65YOuIF-HiM"
    } ]
  },
  "geo" : { },
  "id_str" : "518771505434345474",
  "text" : "RT @MarkDice: Newsweek Magazine Blames Global Warming for Ebola Outbreak    http:\/\/t.co\/OITxOa2tRs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/OITxOa2tRs",
        "expanded_url" : "http:\/\/youtu.be\/65YOuIF-HiM",
        "display_url" : "youtu.be\/65YOuIF-HiM"
      } ]
    },
    "geo" : { },
    "id_str" : "518086854902816768",
    "text" : "Newsweek Magazine Blames Global Warming for Ebola Outbreak    http:\/\/t.co\/OITxOa2tRs",
    "id" : 518086854902816768,
    "created_at" : "2014-10-03 17:15:06 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 518771505434345474,
  "created_at" : "2014-10-05 14:35:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlueberryPancakes",
      "indices" : [ 0, 18 ]
    }, {
      "text" : "Delicious",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/y3IgKYgN4M",
      "expanded_url" : "http:\/\/1drv.ms\/1oIGIsY",
      "display_url" : "1drv.ms\/1oIGIsY"
    } ]
  },
  "geo" : { },
  "id_str" : "518769826106327042",
  "text" : "#BlueberryPancakes #Delicious http:\/\/t.co\/y3IgKYgN4M",
  "id" : 518769826106327042,
  "created_at" : "2014-10-05 14:28:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/N9qx59Fqmw",
      "expanded_url" : "http:\/\/youtu.be\/t5B0x5JaTTw?a",
      "display_url" : "youtu.be\/t5B0x5JaTTw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "518432868431695872",
  "text" : "RT @VigilantChrist: Left Behind or Led Astray ??? Join The Good Fight at Exposing Evil!  http:\/\/t.co\/N9qx59Fqmw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/N9qx59Fqmw",
        "expanded_url" : "http:\/\/youtu.be\/t5B0x5JaTTw?a",
        "display_url" : "youtu.be\/t5B0x5JaTTw?a"
      } ]
    },
    "geo" : { },
    "id_str" : "518017366299385857",
    "text" : "Left Behind or Led Astray ??? Join The Good Fight at Exposing Evil!  http:\/\/t.co\/N9qx59Fqmw",
    "id" : 518017366299385857,
    "created_at" : "2014-10-03 12:38:59 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 518432868431695872,
  "created_at" : "2014-10-04 16:10:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/THddz0U0P3",
      "expanded_url" : "http:\/\/1drv.ms\/1vFfBoE",
      "display_url" : "1drv.ms\/1vFfBoE"
    } ]
  },
  "geo" : { },
  "id_str" : "518429984952569856",
  "text" : "Had quesadillas at the Coney Grille (3.7\/5 stars), not the best service. http:\/\/t.co\/THddz0U0P3",
  "id" : 518429984952569856,
  "created_at" : "2014-10-04 15:58:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Papa John's Pizza",
      "screen_name" : "PapaJohns",
      "indices" : [ 0, 10 ],
      "id_str" : "18450106",
      "id" : 18450106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/YEqkFVtPiD",
      "expanded_url" : "http:\/\/1drv.ms\/1pqqa9l",
      "display_url" : "1drv.ms\/1pqqa9l"
    } ]
  },
  "geo" : { },
  "id_str" : "517335835956350976",
  "in_reply_to_user_id" : 18450106,
  "text" : "@papajohns So this happened http:\/\/t.co\/YEqkFVtPiD",
  "id" : 517335835956350976,
  "created_at" : "2014-10-01 15:30:49 +0000",
  "in_reply_to_screen_name" : "PapaJohns",
  "in_reply_to_user_id_str" : "18450106",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]